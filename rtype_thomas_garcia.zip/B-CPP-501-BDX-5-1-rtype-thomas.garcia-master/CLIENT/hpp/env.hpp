#ifndef ENV_HPP_
#define ENV_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <memory>
#include <vector>
#include "game.hpp"
#include "menu.hpp"
#include "lobby.hpp"
#include "pause.hpp"
#include "state.hpp"
#include <SFML/Graphics/Color.hpp>
#include "../SERVER/src/Network/DataBuffer/DataBuffer.hpp"

class ENV {
    public:
        ENV();
        ~ENV();
        void backgroundParallax();
        int Core();
        int updateState();
    protected:
        std::shared_ptr<DataBuffer> tcpDataBuffer;
        std::shared_ptr<sf::RenderWindow> _window;
        state _status;
        std::vector<sf::IntRect> _boundsView;
        std::vector<sf::Sprite> _bgSprite;
        std::vector<sf::Texture> _textureView;
        sf::Clock _clock;
        std::shared_ptr<sf::Music> _theme;
    private:
};

#endif /* !ENV_HPP_ */