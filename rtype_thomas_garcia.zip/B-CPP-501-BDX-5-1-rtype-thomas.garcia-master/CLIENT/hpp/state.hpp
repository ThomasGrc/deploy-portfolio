#ifndef STATE_HPP_
#define STATE_HPP_

enum class state {
    MENU,
    OPTION,
    LOBBY,
    GAME,
    PAUSE,
};

#endif /* !STATE_HPP_ */