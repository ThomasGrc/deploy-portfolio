#ifndef MENU_HPP_
#define MENU_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <memory>
#include "state.hpp"
#include "../Network/TcpClient/TcpClient.hpp"

class MENU {
    public:
        MENU(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer);
        ~MENU();
        int menu(state &_status, std::shared_ptr<TcpClient> client);
        void updateString(state &status, std::shared_ptr<TcpClient> client);
        void connectClient(state &status, std::shared_ptr<TcpClient> client);
    protected:
        std::shared_ptr<sf::RenderWindow> _window;
        sf::Sprite _overlaySprite;
        sf::Texture _overlayTexture;
        state status;
        sf::RectangleShape _inputBox;
        std::string _inputString;
        sf::Text _inputText;
        sf::Text _pressEnterText;
        sf::Font _font;
        std::shared_ptr<DataBuffer> _tcpDataBuffer;

    private:
};

#endif /* !MENU_HPP_ */