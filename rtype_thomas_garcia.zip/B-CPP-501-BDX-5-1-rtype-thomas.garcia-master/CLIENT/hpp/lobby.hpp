#ifndef LOBBY_HPP_
#define LOBBY_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include <SFML/Audio.hpp>
#include "../SERVER/src/Server/DataBuffer/DataBuffer.hpp"
#include "../SERVER/src/Server/TcpClient/TcpClient.hpp"
#include <memory>

class LOBBY {
    public:
        LOBBY(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer);
        ~LOBBY();
        int lobby(std::shared_ptr<sf::Music>, std::shared_ptr<TcpClient> client);
        void eventcall(std::shared_ptr<TcpClient> client);
        void optioncall(std::shared_ptr<sf::Music>);
        void readycall(std::shared_ptr<TcpClient> client);
    protected:
        std::shared_ptr<sf::RenderWindow> _window;
        sf::Sprite _overlaySprite;
        sf::Texture _overlayTexture;

        sf::Font _font;

        sf::Text _optionText;
        sf::Text _readyText;

        sf::FloatRect _optionRect;
        sf::FloatRect _readyRect;

        sf::Sprite _optionOverlay;
        sf::Texture _optionTexture;

        sf::Text _increaseText;
        sf::Text _decreaseText;

        sf::FloatRect _increaseRect;
        sf::FloatRect _decreaseRect;

        int _volume;
        sf::Text _volumeText;
        sf::Text _volumeTitle;

        int _menuState;

        sf::Music readySound;

        sf::Text _playerReadyText;
        bool _ready;
        int nbPlayerReady;
        std::shared_ptr<DataBuffer> _tcpDataBuffer;
    private:
};

#endif /* !LOBBY_HPP_ */