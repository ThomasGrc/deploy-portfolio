#ifndef GAME_HPP_
#define GAME_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <memory>
#include <vector>
#include <SFML/Graphics/Color.hpp>
#include "../../SERVER/src/Server/TcpClient/TcpClient.hpp"

enum class entityType {
    AMISSILE = 31,
    APERSO = 51,
    EMISSILE = 30,
    EPERSO = 50,
};

enum class playerNb { 
    PLAYER1,
    PLAYER2,
    PLAYER3,
    PLAYER4,
};

class GAME {
    public:
        GAME(std::shared_ptr<sf::RenderWindow> window);
        ~GAME();
        int game(std::shared_ptr<TcpClient> client);
        void initEntity(std::string);
        void updateEntity();
        void emissile();
        void aperso();
        void amissile();
        void eperso();
    protected:
        std::vector<sf::RectangleShape> _shapedEntityRA;
        std::vector<sf::CircleShape> _shapedEntityCA;
        std::vector<sf::RectangleShape> _shapedEntityRE;
        std::vector<sf::CircleShape> _shapedEntityCE;
        entityType _type;
        playerNb _nbPlayer;

    private:
};

#endif /* !GAME_HPP_ */