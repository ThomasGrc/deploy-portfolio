/**
 * \file game.cpp
 * \brief game.
 * \version 0.2
 * \date 13 Novembre 2020
 *
 */

#include "../hpp/game.hpp"

//!
//! Constructor of class GAME
//!

GAME::GAME(std::shared_ptr<sf::RenderWindow> window)
{
}

//!
//! Destructor of class GAME
//!

GAME::~GAME()
{
}

//!
//! drawing the sprites after receiving their name and position from the server
//!

int GAME::game(std::shared_ptr<TcpClient> client)
{

	return (0);
}

//!
//! Create any entity necessary for the game (enemy, player(with color), missiles)
//!
void GAME::initEntity(std::string entityName)
{
	updateEntity();
	switch (this->_type)
	{
	case entityType::AMISSILE:
		this->amissile();
		break;
	case entityType::EMISSILE:
		this->emissile();
		break;
	case entityType::APERSO:
		this->aperso();
		break;
	case entityType::EPERSO:
		this->eperso();
		break;			
	default:
		break;
	}
}

//!
//! Update the entity state entityType::APERSO by default
//!
void GAME::updateEntity()
{
	this->_type = entityType::APERSO; //! WARNING DEFAULT PARAMETER 
}

//!
//! Enemy missile constructor
//!
void GAME::emissile()
{
	sf::CircleShape circle;
	circle.setRadius(static_cast<float>(entityType::EMISSILE));
	circle.setFillColor(sf::Color::Red);
	this->_shapedEntityCE.push_back(circle);
}

//!
//! Enemy constructor
//!
void GAME::eperso()
{
	sf::RectangleShape rectangle;
	rectangle.setSize(sf::Vector2f(static_cast<float>(entityType::EPERSO), static_cast<float>(entityType::EPERSO)));
	rectangle.setFillColor(sf::Color::Red);
	this->_shapedEntityRE.push_back(rectangle);
}

//!
//! Player missile constructor
//!

void GAME::amissile()
{
	sf::CircleShape circle;
	circle.setRadius(static_cast<float>(entityType::AMISSILE));
	circle.setFillColor(sf::Color::Green);
	this->_shapedEntityCA.push_back(circle);
}

//!
//! Player constructor
//!
void GAME::aperso()
{
	sf::RectangleShape rectangle;
	rectangle.setSize(sf::Vector2f(static_cast<float>(entityType::APERSO), static_cast<float>(entityType::APERSO)));
	switch (this->_nbPlayer)
	{
	case playerNb::PLAYER1:
		rectangle.setFillColor(sf::Color::Blue);
		break;
	case playerNb::PLAYER2:
		rectangle.setFillColor(sf::Color::Red);
		break;
	case playerNb::PLAYER3:
		rectangle.setFillColor(sf::Color::Yellow);
		break;
	case playerNb::PLAYER4:
		rectangle.setFillColor(sf::Color::Green);
		break;
	default:
		break;
	}
	this->_shapedEntityRA.push_back(rectangle);
}