#include "../hpp/lobby.hpp"

//!
//! Constructor of class LOBBY
//!
LOBBY::LOBBY(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer)
{
	this->_window = window;

	this->_overlayTexture.loadFromFile("../../CLIENT/assets/lobbyoverlay.png");
	this->_overlaySprite.setTexture(this->_overlayTexture);
	this->_overlaySprite.setPosition(50, 50);

	this->_optionTexture.loadFromFile("../../CLIENT/assets/optionoverlay.png");
	this->_optionOverlay.setTexture(this->_optionTexture);
	this->_optionOverlay.setTextureRect({650, 500, 700, 527});
	this->_optionOverlay.setPosition(800, 95);

	this->_font = sf::Font();
	this->_font.loadFromFile("../../CLIENT/assets/font.otf");

	this->_optionText = sf::Text("OPTIONS", this->_font);
	this->_readyText = sf::Text("READY", this->_font);

	this->_optionText.setPosition(1000, 200);
	this->_readyText.setPosition(1000, 400);

	this->_optionText.setCharacterSize(50);
	this->_readyText.setCharacterSize(50);

	this->_optionRect = this->_optionText.getGlobalBounds();
	this->_readyRect = this->_readyText.getGlobalBounds();

	this->_increaseText = sf::Text("+", this->_font);
	this->_decreaseText = sf::Text("-", this->_font);

	this->_increaseText.setPosition(1300, 300);
	this->_decreaseText.setPosition(900, 300);

	this->_increaseText.setCharacterSize(150);
	this->_decreaseText.setCharacterSize(150);

	this->_increaseRect = this->_increaseText.getGlobalBounds();
	this->_decreaseRect = this->_decreaseText.getGlobalBounds();

	this->_volumeText = sf::Text("_volume", this->_font);
	this->_volumeText.setPosition(1070, 325);
	this->_volumeText.setCharacterSize(100);

	this->_volumeTitle = sf::Text("VOLUME", this->_font);
	this->_volumeTitle.setPosition(810, 100);
	this->_volumeTitle.setCharacterSize(50);

	this->_menuState = 0;
	this->_volume = 50;

	this->_playerReadyText = sf::Text("PLAYER X is READY !", this->_font);
	this->_playerReadyText.setPosition(110, 105);
	this->_playerReadyText.setCharacterSize(20);

	this->readySound.openFromFile("../../CLIENT/assets/ready.ogg");
	this->readySound.setVolume(50);

	this->_ready = false;
	this->nbPlayerReady = 0;
	this->_tcpDataBuffer = tcpDataBuffer;
}

//!
//! Destructor of class LOBBY
//!
LOBBY::~LOBBY()
{

}

//!
//! Main function of LOBBY
//!
int LOBBY::lobby(std::shared_ptr<sf::Music> theme, std::shared_ptr<TcpClient> client)
{
	this->eventcall(client);

	this->_window->draw(this->_overlaySprite);
	this->_window->draw(this->_optionText);
	this->_window->draw(this->_readyText);

	if (this->_menuState == 1)
		this->optioncall(theme);
	if (this->_ready == true)
		this->readycall(client);

	return (0);
}

//!
//! Events loop with the ready button
//!
void LOBBY::eventcall(std::shared_ptr<TcpClient> client)
{
	sf::Event event;
	while (this->_window->pollEvent(event)) {
		if (event.type == sf::Event::Closed)
			this->_window->close();
		if (event.type == sf::Event::MouseButtonPressed) {
			if (this->_optionRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y)))
				this->_menuState = 1;
			if (this->_readyRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y))) {
				this->readySound.play();
				this->_ready = true;
			}
			if (this->_menuState == 1) {
				if (this->_volume < 100 && this->_increaseRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y)))
					this->_volume += 5;
				if (this->_volume > 0 && this->_decreaseRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y)))
					this->_volume -= 5;
			}
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
			this->_menuState = 0;
	}
}

//!
//! Call of the option MENU
//!
void LOBBY::optioncall(std::shared_ptr<sf::Music> theme)
{
	this->_volumeText.setString(std::to_string(this->_volume));
	theme->setVolume(this->_volume);
	this->_window->draw(this->_optionOverlay);
	this->_window->draw(this->_increaseText);
	this->_window->draw(this->_decreaseText);
	this->_window->draw(this->_volumeText);
	this->_window->draw(this->_volumeTitle);
}

//!
//! Send ready to the server when client is ready
//!
void LOBBY::readycall(std::shared_ptr<TcpClient> client)
{
	client->sendMessage("ready");
	while (!this->_tcpDataBuffer->getReceivedData().empty()) {
		std::string data = this->_tcpDataBuffer->popReceivedData();
		std::cout << "client received: " << data << std::endl;
    }
	this->_window->draw(this->_playerReadyText);
}