#include "../hpp/env.hpp"
#include <iostream>

//!
//! Constructor of class ENV
//!
ENV::ENV()
{
    _window = std::make_shared<sf::RenderWindow>();
    _window->create(sf::VideoMode(1600, 900), "RTYPE");
    sf::FloatRect boundsView(0.f, 0.f, 1600.f, 9000.f);
    sf::IntRect iBounds(boundsView);
    sf::Texture texture;

    this->_status = state::MENU;
    for (int i = 0; i != 3; i++)
        this->_textureView.push_back(texture);

    this->_textureView.at(0).loadFromFile("../../CLIENT/assets/bg.png");
    this->_textureView.at(1).loadFromFile("../../CLIENT/assets/bg1.png");
    this->_textureView.at(2).loadFromFile("../../CLIENT/assets/bg2.png");

    for (int i = 0; i != 3; i++) {
        this->_textureView.at(i).setRepeated(true);
        sf::Sprite bgSprite(this->_textureView.at(i), { 0, 0, 1600, 900 });
        bgSprite.setPosition(boundsView.left, boundsView.top);
        this->_bgSprite.push_back(bgSprite);
        this->_boundsView.push_back(iBounds);
    }
    this->_theme = std::make_shared<sf::Music>();
    this->_theme->openFromFile("../../CLIENT/assets/theme.ogg");
    this->_theme->setVolume(0);
    this->_theme->setLoop(true);
    this->_theme->play();
}

//!
//! Destructor of class ENV
//!
ENV::~ENV()
{

}

//!
//! Background parallax for graphic client
//!
void ENV::backgroundParallax()
{
    sf::Time elapsed = this->_clock.getElapsedTime();
    if (elapsed.asMicroseconds() > 5000) {
        this->_boundsView.at(0).left += 1;
        this->_boundsView.at(1).left += 2;
        this->_boundsView.at(2).left += 3;
        for (int i = 0; i != 3; i++)
            this->_bgSprite.at(i).setTextureRect(this->_boundsView.at(i));
        this->_clock.restart();
    }
    for (int i = 0; i != 3; i++)
        _window->draw(this->_bgSprite.at(i));
}

//!
//! Core of the program, equivalent to a main 
//!
int ENV::Core()
{
    tcpDataBuffer = std::make_shared<DataBuffer>();
    std::unique_ptr<MENU> menu = std::make_unique<MENU>(this->_window, tcpDataBuffer);
    std::unique_ptr<GAME> game = std::make_unique<GAME>(this->_window);
    std::unique_ptr<LOBBY> lobby = std::make_unique<LOBBY>(this->_window, tcpDataBuffer);
    std::unique_ptr<PAUSE> pause = std::make_unique<PAUSE>(this->_window);
    std::shared_ptr<TcpClient> client = std::make_shared<TcpClient>(tcpDataBuffer);

    while (this->_window->isOpen()) {
        this->_window->clear();
        this->backgroundParallax();
        // std::cout << static_cast<int>(this->_status) << std::endl;

        switch (this->_status) {
            case state::MENU:
                menu->menu(this->_status, client);
                break;
            case state::GAME:
                game->game(client);
                break;
            case state::LOBBY:
                lobby->lobby(this->_theme, client);
                break;
            case state::PAUSE:
                pause->pause(client);
                break;
            default:
                break;
		}
        this->updateState();
        this->_window->display();
    }
    return (0);
}

//!
//! Update the state of the client
//!
int ENV::updateState()
{
    while (!this->tcpDataBuffer->getReceivedData().empty()) {
        std::string data = this->tcpDataBuffer->popReceivedData();
        std::cout << "client received: " << data << std::endl;
        if (data == "game")
            this->_status = state::GAME;
    }
    return (0);
}