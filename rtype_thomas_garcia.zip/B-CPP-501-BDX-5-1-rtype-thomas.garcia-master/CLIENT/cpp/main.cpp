#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include "../hpp/env.hpp"
#include "../../Exception/ExceptionClient.hpp"

//!
//! Main function of program, simply call env->core
//!
int main()
{
    try {
        std::shared_ptr<ENV> env = std::make_shared<ENV>();
        env->Core();
        return 0;
    } catch (const ExceptionClient& e) {
        std::cerr << e.what() << std::endl;
    }
}