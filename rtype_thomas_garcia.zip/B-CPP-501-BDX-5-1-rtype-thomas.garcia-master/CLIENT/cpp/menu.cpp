#include "../hpp/menu.hpp"
#include "../../SERVER/src/Server/TcpClient/TcpClient.hpp"

//!
//! Constructor of class MENU
//!
MENU::MENU(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer)
{
	this->_tcpDataBuffer = tcpDataBuffer;
	this->_window = window;
	this->_inputString = "";
	this->_overlayTexture.loadFromFile("../../CLIENT/assets/menuoverlay.png");
	this->_overlaySprite.setTexture(this->_overlayTexture);
	this->_overlaySprite.setPosition(50, 50);
	this->_inputBox.setSize(sf::Vector2f(250, 50));
	this->_inputBox.setOutlineColor(sf::Color::White);
	this->_inputBox.setFillColor(sf::Color::Black);
	this->_inputBox.setOutlineThickness(5);
	this->_inputBox.setPosition(1070, 750);
	this->_font = sf::Font();
	this->_font.loadFromFile("../../CLIENT/assets/font.otf");
	this->_inputText = sf::Text("XXX.XXX.X.X", this->_font);
	this->_pressEnterText = sf::Text("PRESS ENTER", this->_font);
	this->_inputText.setFillColor(sf::Color::White);
	this->_pressEnterText.setFillColor(sf::Color::White);
	this->_inputText.setPosition(1075, 755);
	this->_pressEnterText.setPosition(1340, 760);
	this->_inputText.setCharacterSize(30);
	this->_pressEnterText.setCharacterSize(25);
}

//!
//! Destructor of class MENU
//!
MENU::~MENU()
{

}

//!
//! Main function of MENU
//!

int MENU::menu(state &_status, std::shared_ptr<TcpClient> client)
{
	this->updateString(_status, client);
	this->_window->draw(this->_overlaySprite);
	this->_window->draw(this->_inputBox);
	this->_window->draw(this->_inputText);
	this->_window->draw(this->_pressEnterText);
	return (0);
}

//!
//! Loop event of the menu
//!
void MENU::updateString(state &status, std::shared_ptr<TcpClient> client)
{
	sf::Event event;
	while (this->_window->pollEvent(event)) {
		if (event.type == sf::Event::Closed)
			this->_window->close();
		if (event.type == sf::Event::TextEntered) {
			if (event.text.unicode < 128 && event.text.unicode != 8 && this->_inputString.length() < 15) {
				this->_inputString += static_cast<char>(event.text.unicode);
			}
			if (event.text.unicode == 8 && this->_inputString != "")
				this->_inputString.pop_back();
			this->_inputText.setString(this->_inputString);
		}
		if ((event.type == sf::Event::KeyPressed) && (event.key.code == sf::Keyboard::Enter)) {
			this->connectClient(status, client);
		}
	}
}

//!
//! Connect to client with port and ip addr
//!
void MENU::connectClient(state &status, std::shared_ptr<TcpClient> client)
{
	size_t pos = this->_inputString.find_first_of(':');
	if (pos < 2) {
        throw ExceptionClient("Command not found", "menu.hpp");
	}
	std::string port(this->_inputString);
	port.erase(0, pos + 1);
	this->_inputString.erase(pos, this->_inputString.size() - pos);

	std::cout << port << std::endl;
	std::cout << this->_inputString << std::endl;
	client->connect(this->_inputString, port);
	client->receiveMessage(); // async loop
	// client->sendMessage("salut");
	// std::cout << client->receiveMessage() << std::endl;
}