#include "../hpp/pause.hpp"
//!
//! Constructor of class PAUSE
//!
PAUSE::PAUSE(std::shared_ptr<sf::RenderWindow> window)
{

}

//!
//! Destructor of class PAUSE
//!
PAUSE::~PAUSE()
{

}

//!
//! Main function of PAUSE
//!
int PAUSE::pause(std::shared_ptr<TcpClient> client)
{
	return (0);
}