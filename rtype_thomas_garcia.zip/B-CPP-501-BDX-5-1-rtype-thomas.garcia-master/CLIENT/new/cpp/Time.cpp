/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Time
*/

#include "../hpp/Time.hpp"

Time::Time()
{
}

Time::~Time()
{
}

// returns the current time
std::clock_t Time::getTime() const
{
    return (std::clock());
}

// Returns the elapsed time since the beginning of the frame
double Time::getDeltaTime() const
{
    return ((getTime() - frameBgnTime) / (double)CLOCKS_PER_SEC);
}

// Returns the time since the last update call. DO NOT USE
double Time::getUpdateDeltaTime() const
{
    return ((getTime() - updateBgnTime) / (double)CLOCKS_PER_SEC);
}

// Returns elapsed time since the last frame. Use this for physics related updates, ...
double Time::getTimeSinceLastFrame() const
{
    return (totalFrameTime + getDeltaTime());
}