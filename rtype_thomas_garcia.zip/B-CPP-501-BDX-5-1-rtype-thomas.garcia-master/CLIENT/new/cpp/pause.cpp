#include "../hpp/pause.hpp"

Pause::Pause(std::shared_ptr<sf::RenderWindow> window)
{

}

Pause::~Pause()
{

}

int Pause::run(std::shared_ptr<TcpClient> client)
{
	return (0);
}