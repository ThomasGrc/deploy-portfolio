#include "../hpp/Lobby.hpp"

Lobby::Lobby(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<PlayerInfos> &playerInfos_)
{
	this->_window = window;

	this->_overlayTexture.loadFromFile("../CLIENT/assets/Lobbyoverlay.png");
	this->_overlaySprite.setTexture(this->_overlayTexture);
	this->_overlaySprite.setPosition(50, 50);

	this->_optionTexture.loadFromFile("../CLIENT/assets/optionoverlay.png");
	this->_optionOverlay.setTexture(this->_optionTexture);
	this->_optionOverlay.setTextureRect({650, 500, 700, 527});
	this->_optionOverlay.setPosition(800, 95);

	this->_font = sf::Font();
	this->_font.loadFromFile("../CLIENT/assets/font.otf");

	this->_optionText = sf::Text("OPTIONS", this->_font);
	this->_readyText = sf::Text("READY", this->_font);

	this->_optionText.setPosition(1000, 200);
	this->_readyText.setPosition(1000, 400);

	this->_optionText.setCharacterSize(50);
	this->_readyText.setCharacterSize(50);

	this->_optionRect = this->_optionText.getGlobalBounds();
	this->_readyRect = this->_readyText.getGlobalBounds();

	this->_increaseText = sf::Text("+", this->_font);
	this->_decreaseText = sf::Text("-", this->_font);

	this->_increaseText.setPosition(1300, 300);
	this->_decreaseText.setPosition(900, 300);

	this->_increaseText.setCharacterSize(150);
	this->_decreaseText.setCharacterSize(150);

	this->_increaseRect = this->_increaseText.getGlobalBounds();
	this->_decreaseRect = this->_decreaseText.getGlobalBounds();

	this->_volumeText = sf::Text("_volume", this->_font);
	this->_volumeText.setPosition(1070, 325);
	this->_volumeText.setCharacterSize(100);

	this->_volumeTitle = sf::Text("VOLUME", this->_font);
	this->_volumeTitle.setPosition(810, 100);
	this->_volumeTitle.setCharacterSize(50);

	this->_menuState = 0;
	this->_volume = 50;

	this->_playerReadyText = sf::Text("PLAYER X is READY !", this->_font);
	this->_playerReadyText.setPosition(110, 105);
	this->_playerReadyText.setCharacterSize(20);

	this->readySound.openFromFile("../CLIENT/assets/ready.ogg");
	this->readySound.setVolume(50);

	this->_ready = false;
	this->_isReady = false;
	this->_hasJoined = false;
	this->nbPlayerReady = 0;
	this->_tcpDataBuffer = tcpDataBuffer;
	this->playerInfos = playerInfos_;
}

Lobby::~Lobby()
{

}

int Lobby::run(std::shared_ptr<sf::Music> theme, std::shared_ptr<TcpClient> client, std::shared_ptr<UdpClient> udpClient)
{
	this->eventcall(client);

	this->_window->draw(this->_overlaySprite);
	this->_window->draw(this->_optionText);
	this->_window->draw(this->_readyText);

	if (this->_menuState == 1)
		this->optioncall(theme);
	if (this->_ready == true) {
		this->readycall(client);
		this->_ready = false;
	}

	if (!_tcpDataBuffer->getReceivedData().empty()) {
		std::string rawData = _tcpDataBuffer->popReceivedData();
		std::cout << "Lobby::run: " << rawData << std::endl;
		std::string dataType = rawData.substr(0, rawData.find("-"));
		rawData.erase(0, dataType.length() + 1); // + 1 to erase the ' ' char
		std::string payload = rawData;

		if (dataType == "new") {
			if (!this->_hasJoined) {
				this->_hasJoined = true;
				this->playerInfos->playerNb = payload.substr(0, payload.find("-"));
				payload.erase(0, payload.find("-") + 1);
				this->playerInfos->playerName = payload;
			} else {
				payload.erase(0, payload.find("-") + 1);
			}
			this->lobbyTextFeed.push_back(sf::Text(payload + " joined the game", this->_font));
			this->lobbyTextFeed.at(this->lobbyTextFeed.size() - 1).setCharacterSize(20);
			this->lobbyTextFeed.at(this->lobbyTextFeed.size() - 1).setPosition(110, 105 + (20 * (this->lobbyTextFeed.size() - 1) + 5));
		} else if (dataType == "ready") {
			payload.erase(0, payload.find("-") + 1);
			this->lobbyTextFeed.push_back(sf::Text(payload + " is ready", this->_font));
			this->lobbyTextFeed.at(this->lobbyTextFeed.size() - 1).setCharacterSize(20);
			this->lobbyTextFeed.at(this->lobbyTextFeed.size() - 1).setPosition(110, 105 + (20 * (this->lobbyTextFeed.size() - 1) + 5));
		} else if (dataType == "starting") {
			std::cout << "starting game" << std::endl;
			udpClient->connect( this->playerInfos->serverHost, this->playerInfos->serverPort );
			return (1);
		}
	}

	if (this->_hasJoined) {
		for (size_t i = 0; i < this->lobbyTextFeed.size(); i++) {
			this->_window->draw(this->lobbyTextFeed.at(i));
		}
	}

	return (0);
}

void Lobby::eventcall(std::shared_ptr<TcpClient> client)
{
	sf::Event event;
	while (this->_window->pollEvent(event)) {
		if (event.type == sf::Event::Closed)
			this->_window->close();
		if (event.type == sf::Event::MouseButtonPressed) {
			if (this->_optionRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y)))
				this->_menuState = 1;
			if (this->_readyRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y))) {
				this->readySound.play();
				this->_ready = true;
			}
			if (this->_menuState == 1) {
				if (this->_volume < 100 && this->_increaseRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y)))
					this->_volume += 5;
				if (this->_volume > 0 && this->_decreaseRect.contains(static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).x), static_cast<float>(sf::Mouse::getPosition(*(this->_window.get())).y)))
					this->_volume -= 5;
			}
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
			this->_menuState = 0;
	}
}

void Lobby::optioncall(std::shared_ptr<sf::Music> theme)
{
	this->_volumeText.setString(std::to_string(this->_volume));
	theme->setVolume(this->_volume);
	this->_window->draw(this->_optionOverlay);
	this->_window->draw(this->_increaseText);
	this->_window->draw(this->_decreaseText);
	this->_window->draw(this->_volumeText);
	this->_window->draw(this->_volumeTitle);
}



void Lobby::readycall(std::shared_ptr<TcpClient> client)
{
	if (!this->_isReady) {
		client->start_write("ready-" + this->playerInfos->playerNb + "-" + this->playerInfos->playerName + "\n");
		this->_isReady = true;
	} else {
		// TODO send "unready" msg
		this->_isReady = false;
	}
}