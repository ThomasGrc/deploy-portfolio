#include "../hpp/Options.hpp"

Options::Options(std::shared_ptr<sf::RenderWindow> window)
{

}

Options::~Options()
{

}

int Options::run(std::shared_ptr<TcpClient> client)
{
	return (0);
}