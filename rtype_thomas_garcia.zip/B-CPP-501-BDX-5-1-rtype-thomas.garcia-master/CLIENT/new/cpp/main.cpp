#include <memory>
#include <mutex>
#include <iostream>
#include "../hpp/Core.hpp"
#include "../Network/TcpClient/TcpClient.hpp"
  
int main(int argc, char* argv[]) 
{ 
    try
    {
        Core core;

        core.start();
    }
    catch (std::exception& e)
    {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}