#include "../hpp/Menu.hpp"

Menu::Menu(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<PlayerInfos> &playerInfos_)
{
	this->currentInput = 0;
	this->playerInfos = playerInfos_;
	this->_tcpDataBuffer = tcpDataBuffer;
	this->_window = window;
	this->_overlayTexture.loadFromFile("../CLIENT/assets/menuoverlay.png");
	this->_overlaySprite.setTexture(this->_overlayTexture);
	this->_overlaySprite.setPosition(50, 50);

	this->logoTexture.loadFromFile("../CLIENT/new/assets/r_type_logo.png");
	this->logoSprite.setTexture(this->logoTexture);
	this->logoSprite.setPosition(450, 100); // x = window_size.x / 2 - (texture_length(700) / 2)

	this->_pseudoInputBox.setSize(sf::Vector2f(375, 75));
	this->_pseudoInputBox.setOutlineColor(sf::Color::White);
	this->_pseudoInputBox.setFillColor(sf::Color::Black);
	this->_pseudoInputBox.setOutlineThickness(5);
	this->_pseudoInputBox.setPosition(612.5, 412.5); // x = window_size.x / 2 - (_pseudoInputBox.x / 2), y = window_size.y / 2 - (_pseudoInputBox.y / 2)
	this->_pseudoInputHitBox = sf::Rect<double>(612.5, 412.5, 375.0, 75.0);
	this->_pseudoInputString = "";

	this->_pseudoInputText = sf::Text("PLAYER NAME", this->_font);
	this->_pseudoInputText.setFillColor(sf::Color::White);
	this->_pseudoInputText.setPosition(617.5, 417.5); // _pseudoInputBox + 5px
	this->_pseudoInputText.setCharacterSize(45);

	this->_ipInputString = "";
	this->_ipInputBox.setSize(sf::Vector2f(375, 75));
	this->_ipInputBox.setOutlineColor(sf::Color::White);
	this->_ipInputBox.setFillColor(sf::Color::Black);
	this->_ipInputBox.setOutlineThickness(5);
	this->_ipInputBox.setPosition(612.5, 507.5); // x = _pseudoInputBox_x_pos , y = _pseudoInputBox_y_pos + _pseudoInputBox_height + 20
	this->_ipInputHitBox = sf::Rect<double>(612.5, 507.5, 375.0, 75.0);
	this->_ipInputText = sf::Text("XXX.XXX.X.X", this->_font);
	this->_ipInputText.setFillColor(sf::Color::White);
	this->_ipInputText.setPosition(615.5, 512.5); // _ipInputBox + 5px
	this->_ipInputText.setCharacterSize(45);

	this->_font = sf::Font();
	this->_font.loadFromFile("../CLIENT/assets/font.otf");

	this->_pressEnterText = sf::Text("PRESS ENTER", this->_font);
	this->_pressEnterText.setFillColor(sf::Color::White);
	this->_pressEnterText.setPosition(1000.5, 512.5); // x = _ipInputText_x_pos + _ipInputBox_length + 10px ; y = _ipInputText_y_pos
	this->_pressEnterText.setCharacterSize(45);
}

Menu::~Menu()
{

}

int Menu::run(state &_status, std::shared_ptr<TcpClient> client, std::shared_ptr<boost::asio::io_context> &io_context)
{
	this->updateString(_status, client, io_context);
	this->_window->draw(this->_overlaySprite);
	this->_window->draw(this->_ipInputBox);
	this->_window->draw(this->_ipInputText);
	this->_window->draw(this->_pseudoInputBox);
	this->_window->draw(this->_pseudoInputText);
	this->_window->draw(this->_pressEnterText);
	this->_window->draw(this->logoSprite);
	if (!_tcpDataBuffer->getReceivedData().empty()) {
		std::string dataType = _tcpDataBuffer->getReceivedData().at(0);
		if (dataType.substr(0, dataType.find("-")) == "connected") {// player successfuly connected
			this->playerInfos->playerName = this->_pseudoInputString;
			client->start_write("new-" + this->playerInfos->playerName + "\n");
			return (1);
		} else
			return (0);
	}
	return (0);
}

void Menu::updateString(state &status, std::shared_ptr<TcpClient> client, std::shared_ptr<boost::asio::io_context> &io_context)
{
	sf::Event event;
	while (this->_window->pollEvent(event)) {
		if (event.type == sf::Event::Closed)
			this->_window->close();
		if (event.type == sf::Event::TextEntered) {
			if (event.text.unicode != 32 && event.text.unicode < 128 && event.text.unicode != 8 && this->_ipInputString.length() < 15) {
				if (this->currentInput == 1) {
					this->_ipInputString += static_cast<char>(event.text.unicode);
					this->_ipInputText.setString(this->_ipInputString);
				} else if (this->currentInput == 0) {
					this->_pseudoInputString += static_cast<char>(event.text.unicode);
					this->_pseudoInputText.setString(this->_pseudoInputString);
				}
			}
			if (event.text.unicode == 8) {
				if (this->currentInput == 1 && this->_ipInputString != "") {
					this->_ipInputString.pop_back();
					this->_ipInputText.setString(this->_ipInputString);
				} else if (this->currentInput == 0 && this->_pseudoInputString != "") {
					this->_pseudoInputString.pop_back();
					this->_pseudoInputText.setString(this->_pseudoInputString);
				}
			}
		}
		if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
			if (this->_pseudoInputHitBox.contains(event.mouseButton.x, event.mouseButton.y)) {
				this->currentInput = 0;
			} else if (this->_ipInputHitBox.contains(event.mouseButton.x, event.mouseButton.y)) {
				this->currentInput = 1;
			}
		}
		if ((event.type == sf::Event::KeyPressed) && (event.key.code == sf::Keyboard::Enter)) {
			this->connectClient(status, client, io_context);
		}
	}
}

void Menu::connectClient(state &status, std::shared_ptr<TcpClient> client, std::shared_ptr<boost::asio::io_context> &io_context)
{
	size_t pos = this->_ipInputString.find_first_of(':');
	std::string port(this->_ipInputString);
	port.erase(0, pos + 1);
	this->_ipInputString.erase(pos, this->_ipInputString.size() - pos);

	this->playerInfos->serverHost = this->_ipInputString;
	this->playerInfos->serverPort = port;
	tcp::resolver r(*(io_context.get()));
	client->start(r.resolve(this->_ipInputString, port));
	io_context->restart();
}