#include "../hpp/Core.hpp"
#include <iostream>

Core::Core()
{
    _window = std::make_shared<sf::RenderWindow>();
    _window->create(sf::VideoMode(1600, 900), "RTYPE");
    sf::FloatRect boundsView(0.f, 0.f, 1600.f, 9000.f);
    sf::IntRect iBounds(boundsView);
    sf::Texture texture;

    this->_status = state::MENU;
    for (int i = 0; i != 3; i++)
        this->_textureView.push_back(texture);

    this->_textureView.at(0).loadFromFile("../CLIENT/assets/bg.png");
    this->_textureView.at(1).loadFromFile("../CLIENT/assets/bg1.png");
    this->_textureView.at(2).loadFromFile("../CLIENT/assets/bg2.png");

    for (int i = 0; i != 3; i++) {
        this->_textureView.at(i).setRepeated(true);
        sf::Sprite bgSprite(this->_textureView.at(i), { 0, 0, 1600, 900 });
        bgSprite.setPosition(boundsView.left, boundsView.top);
        this->_bgSprite.push_back(bgSprite);
        this->_boundsView.push_back(iBounds);
    }
    this->_theme = std::make_shared<sf::Music>();
    this->_theme->openFromFile("../CLIENT/assets/theme.ogg");
    this->_theme->setVolume(0);
    this->_theme->setLoop(true);
    this->_theme->play();
    playerInfos = std::make_shared<PlayerInfos>();
    playerInfos->playerName = "Player";
}

Core::~Core()
{

}

void Core::backgroundParallax()
{
    this->_boundsView.at(0).left += 121 * this->timeHandler.getTimeSinceLastFrame();
    this->_boundsView.at(1).left += 121 * this->timeHandler.getTimeSinceLastFrame() * 2;
    this->_boundsView.at(2).left += 121 * this->timeHandler.getTimeSinceLastFrame() * 3;
    for (int i = 0; i != 3; i++)
        this->_bgSprite.at(i).setTextureRect(this->_boundsView.at(i));
    for (int i = 0; i != 3; i++)
        _window->draw(this->_bgSprite.at(i));
}


int Core::start()
{
    dataBuffer = std::make_shared<DataBuffer>();
    std::unique_ptr<Menu> menu = std::make_unique<Menu>(this->_window, dataBuffer, this->playerInfos);
    std::unique_ptr<Game> game = std::make_unique<Game>(this->_window, dataBuffer, this->playerInfos);
    std::unique_ptr<Options> option = std::make_unique<Options>(this->_window);
    std::unique_ptr<Lobby> lobby = std::make_unique<Lobby>(this->_window, dataBuffer, this->playerInfos);
    std::unique_ptr<Pause> pause = std::make_unique<Pause>(this->_window);

    std::shared_ptr<boost::asio::io_context> io_context = std::make_shared<boost::asio::io_context>();
    std::shared_ptr<TcpClient> client = std::make_shared<TcpClient>(*(io_context.get()), dataBuffer);
    std::shared_ptr<UdpClient> udpClient = std::make_shared<UdpClient>(*(io_context.get()), dataBuffer);

    double frameTime = 1.0f / this->fps;
    double remainingTime = 0.0;
    size_t updates = 0;
    double totalTime = 0.0;
    int trueFps = 0;

    while (this->_window->isOpen()) {
        trueFps++;
        this->timeHandler.frameBgnTime = timeHandler.getTime();

        this->_window->clear();
        // std::cout << static_cast<int>(this->_status) << std::endl;

        switch (this->_status) {
            case state::MENU:
                if (menu->run(this->_status, client, io_context) == 1)
                    this->_status = state::LOBBY;
                break;
            case state::GAME:
                game->run(udpClient);
                break;
            case state::OPTION:
                option->run(client);
                break;
            case state::LOBBY:
                if (lobby->run(this->_theme, client, udpClient) == 1)
                    this->_status = state::GAME;
                break;
            case state::PAUSE:
                pause->run(client);
                break;
            default:
                break;
		}
        this->updateState();

        this->backgroundParallax();
        this->_window->display();
        io_context->poll();

        remainingTime = frameTime - timeHandler.getDeltaTime();
        updates = 0;
        if (timeHandler.getDeltaTime() < remainingTime) {
            timeHandler.updateBgnTime = timeHandler.getTime();
            while (timeHandler.getUpdateDeltaTime() < remainingTime) {
                timeHandler.updateBgnTime = timeHandler.getTime();
                // if (updates < 5) {
                    // do events ?
                updates++;
                // }
                remainingTime -= timeHandler.getUpdateDeltaTime();
            }
        }
        timeHandler.totalFrameTime = 0;
        timeHandler.totalFrameTime += frameTime - remainingTime;
        // just to print the fps count every sec
        totalTime += frameTime - remainingTime;
        if (totalTime >= 1) {
            std::cout << "fps: " << trueFps << std::endl;
            totalTime = 0;
            trueFps = 0;
        }
    }
    return (0);
}

int Core::updateState()
{
    // while (!this->tcpDataBuffer->getReceivedData().empty()) {
    //     std::string data = this->tcpDataBuffer->popReceivedData();
    //     std::cout << "client received: " << data << std::endl;
    //     if (data == "game")
    //         this->_status = state::GAME;
    // }
    return (0);
}