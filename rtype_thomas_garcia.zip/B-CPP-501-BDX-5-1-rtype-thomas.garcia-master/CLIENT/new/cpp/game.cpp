#include "../hpp/Game.hpp"

Game::Game(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> dataBuffer_, std::shared_ptr<PlayerInfos> &playerInfos_)
{
	this->_window = window;
	this->dataBuffer = dataBuffer_;
	this->playerInfos = playerInfos_;
	this->font.loadFromFile("../CLIENT/assets/font.otf");
}

Game::~Game()
{
}

void Game::addDrawable(std::string type, std::string ID, std::string spriteName, std::string posX, std::string posY)
{
	bool isNew = true;
	
	if (type == "entity") {
		for (size_t i = 0; i < this->entities.size(); i++) {
			if (entities[i].ID == ID) {
				isNew = false;
				entities[i].sprite.setPosition(sf::Vector2f( std::atof(posX.c_str()), std::atof(posY.c_str()) ));
			}
		}
		if (isNew) {
			this->entities.push_back( {std::make_shared<sf::Texture>(), sf::Sprite(), spriteName, ID } );
			this->entities[this->entities.size() - 1].texture->loadFromFile("../CLIENT/new/assets/" + spriteName + ".png");
			this->entities[this->entities.size() - 1].sprite.setTexture( *(this->entities[this->entities.size() - 1].texture.get()) );
			this->entities[this->entities.size() - 1].sprite.setPosition( std::atof(posX.c_str()), std::atof(posY.c_str()) );
		}
	} else if (type == "text") {
		for (size_t i = 0; i < this->texts.size(); i++) {
			if (texts[i].ID == ID) {
				isNew = false;
				texts[i].text.setPosition(sf::Vector2f( std::atof(posX.c_str()), std::atof(posY.c_str()) ));
				texts[i].textString = spriteName;
				texts[i].text.setString(spriteName);
			}
		}
		if (isNew) {
			this->texts.push_back( {sf::Text(spriteName, this->font), spriteName, ID } );
			this->texts[this->texts.size() - 1].text.setPosition( std::atof(posX.c_str()), std::atof(posY.c_str()) );
		}
	} else if (type == "ui") {
		for (size_t i = 0; i < this->uis.size(); i++) {
			if (uis[i].ID == ID) {
				isNew = false;
				uis[i].sprite.setPosition(sf::Vector2f( std::atof(posX.c_str()), std::atof(posY.c_str()) ));
			}
		}
		if (isNew) {
			this->uis.push_back( {std::make_shared<sf::Texture>(), sf::Sprite(), spriteName, ID } );
			this->uis[this->uis.size() - 1].texture->loadFromFile("../CLIENT/new/assets/" + spriteName + ".png");
			this->uis[this->uis.size() - 1].sprite.setTexture( *(this->uis[this->uis.size() - 1].texture.get()) );
			this->uis[this->uis.size() - 1].sprite.setPosition( std::atof(posX.c_str()), std::atof(posY.c_str()) );
		}
	}
}

int Game::run(std::shared_ptr<UdpClient> udpClient)
{
	this->events(udpClient);
	if (!tmp) {
		udpClient->receive();
		udpClient->send("connection\n");
		tmp = true;
	}
	while (!this->dataBuffer->getReceivedData().empty()) {
		std::string rawData = this->dataBuffer->popReceivedData();
		// std::cout << rawData << std::endl;
		
		// get entity type (entity, text, ui)
		std::string type = rawData.substr(0, rawData.find("-"));
		rawData.erase(0, type.length() + 1); // + 1 to erase the '-' char
		// get entity ID
		std::string ID = rawData.substr(0, rawData.find("-"));
		rawData.erase(0, ID.length() + 1); // + 1 to erase the '-' char
		// TODO save object if new ID

		// get entity name
		std::string spriteName = rawData.substr(0, rawData.find("-"));
		rawData.erase(0, spriteName.length() + 1);
		// this->playerTexture.loadFromFile("../CLIENT/new/assets/" + spriteName + ".png"); // TODO not reset on every loop
		// this->playerSprite.setTexture(this->playerTexture);

		// get sprite pos
		std::string pos = rawData.substr(0, rawData.find("-"));
		std::string x = rawData.substr(0, rawData.find(","));
		pos.erase(0, x.length() + 1);
		std::string y = pos;
		// this->playerSprite.setPosition(sf::Vector2f(std::atof(x.c_str()), std::atof(y.c_str())));
		rawData.erase(0, x.length() + 1 + y.length() + 1);
		this->addDrawable(type, ID, spriteName, x, y);
	}
	for (auto entity : this->entities ) {
		this->_window->draw(entity.sprite);
	}
	for (auto text : this->texts ) {
		this->_window->draw(text.text);
	}
	for (auto ui : this->uis ) {
		this->_window->draw(ui.sprite);
	}
	// this->_window->draw(this->playerSprite);

	return (0);
}

void Game::events(std::shared_ptr<UdpClient> udpClient)
{
	sf::Event event;
	while (this->_window->pollEvent(event)) {
		if (event.type == sf::Event::Closed)
			this->_window->close();
		if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::D) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-RIGHT-pressed\n");
		}
		if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Q) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-LEFT-pressed\n");
		}
		if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Z) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-UP-pressed\n");
		}
		if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::S) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-DOWN-pressed\n");
		}
		if (event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::D) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-RIGHT-released\n");
		}
		if (event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Q) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-LEFT-released\n");
		}
		if (event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Z) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-UP-released\n");
		}
		if (event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::S) {
			udpClient->send( "action-" + this->playerInfos->playerNb + "-DOWN-released\n");
		}
	}
}

void Game::initEntity(std::string entityName)
{
	updateEntity();
	switch (this->_type)
	{
	case entityType::AMISSILE:
		this->amissile();
		break;
	case entityType::EMISSILE:
		this->emissile();
		break;
	case entityType::APERSO:
		this->aperso();
		break;
	case entityType::EPERSO:
		this->eperso();
		break;			
	default:
		break;
	}
}

void Game::updateEntity()
{
	this->_type = entityType::APERSO; //! WARNING DEFAULT PARAMETER 
}

void Game::emissile()
{
	sf::CircleShape circle;
	circle.setRadius(static_cast<float>(entityType::EMISSILE));
	circle.setFillColor(sf::Color::Red);
	this->_shapedEntityCE.push_back(circle);
}

void Game::eperso()
{
	sf::RectangleShape rectangle;
	rectangle.setSize(sf::Vector2f(static_cast<float>(entityType::EPERSO), static_cast<float>(entityType::EPERSO)));
	rectangle.setFillColor(sf::Color::Red);
	this->_shapedEntityRE.push_back(rectangle);
}

void Game::amissile()
{
	sf::CircleShape circle;
	circle.setRadius(static_cast<float>(entityType::AMISSILE));
	circle.setFillColor(sf::Color::Green);
	this->_shapedEntityCA.push_back(circle);
}

void Game::aperso()
{
	sf::RectangleShape rectangle;
	rectangle.setSize(sf::Vector2f(static_cast<float>(entityType::APERSO), static_cast<float>(entityType::APERSO)));
	switch (this->_nbPlayer)
	{
	case playerNb::PLAYER1:
		rectangle.setFillColor(sf::Color::Blue);
		break;
	case playerNb::PLAYER2:
		rectangle.setFillColor(sf::Color::Red);
		break;
	case playerNb::PLAYER3:
		rectangle.setFillColor(sf::Color::Yellow);
		break;
	case playerNb::PLAYER4:
		rectangle.setFillColor(sf::Color::Green);
		break;
	default:
		break;
	}
	this->_shapedEntityRA.push_back(rectangle);
}