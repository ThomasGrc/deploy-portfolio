#ifndef LOBBY_HPP_
#define LOBBY_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include "./PlayerInfos.hpp"
#include "../Network/TcpClient/TcpClient.hpp"
#include "../Network/UdpClient/UdpClient.hpp"
#include <SFML/Audio.hpp>
#include <memory>

class Lobby {
    public:
        Lobby(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<PlayerInfos> &playerInfos_);
        ~Lobby();
        int run(std::shared_ptr<sf::Music>, std::shared_ptr<TcpClient> client, std::shared_ptr<UdpClient> udpClient);
        void eventcall(std::shared_ptr<TcpClient> client);
        void optioncall(std::shared_ptr<sf::Music>);
        void readycall(std::shared_ptr<TcpClient> client);
    protected:
        std::shared_ptr<sf::RenderWindow> _window;
        sf::Sprite _overlaySprite;
        sf::Texture _overlayTexture;

        sf::Font _font;

        sf::Text _optionText;
        sf::Text _readyText;

        sf::FloatRect _optionRect;
        sf::FloatRect _readyRect;

        sf::Sprite _optionOverlay;
        sf::Texture _optionTexture;

        sf::Text _increaseText;
        sf::Text _decreaseText;

        sf::FloatRect _increaseRect;
        sf::FloatRect _decreaseRect;

        int _volume;
        sf::Text _volumeText;
        sf::Text _volumeTitle;

        int _menuState;

        sf::Music readySound;

        sf::Text _playerReadyText;
        std::vector<sf::Text> lobbyTextFeed;
        bool _ready;
        bool _isReady;
        bool _hasJoined;
        int nbPlayerReady;
        std::shared_ptr<PlayerInfos> playerInfos;
        std::shared_ptr<DataBuffer> _tcpDataBuffer;
    private:
};

#endif /* !LOBBY_HPP_ */