#ifndef MENU_HPP_
#define MENU_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <memory>
#include "./PlayerInfos.hpp"
#include "state.hpp"
#include "../Network/TcpClient/TcpClient.hpp"

class Menu {
    public:
        Menu(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<PlayerInfos> &playerInfos_);
        ~Menu();
        int run(state &_status, std::shared_ptr<TcpClient> client, std::shared_ptr<boost::asio::io_context> &io_context);
        void updateString(state &status, std::shared_ptr<TcpClient> client, std::shared_ptr<boost::asio::io_context> &io_context);
        void connectClient(state &status, std::shared_ptr<TcpClient> client, std::shared_ptr<boost::asio::io_context> &io_context);
    protected:
        std::shared_ptr<sf::RenderWindow> _window;
        sf::Sprite _overlaySprite;
        sf::Texture _overlayTexture;
        state status;
        
        sf::RectangleShape _ipInputBox;
        sf::Rect<double> _ipInputHitBox;
        std::string _ipInputString;
        sf::Text _ipInputText;

        sf::RectangleShape _pseudoInputBox;
        sf::Rect<double> _pseudoInputHitBox;
        std::string _pseudoInputString;
        sf::Text _pseudoInputText;

        int currentInput;

        sf::Texture logoTexture;
        sf::Sprite logoSprite;

        sf::Text _pressEnterText;
        sf::Font _font;
        std::shared_ptr<DataBuffer> _tcpDataBuffer;
        std::shared_ptr<PlayerInfos> playerInfos;

    private:
};

#endif /* !MENU_HPP_ */