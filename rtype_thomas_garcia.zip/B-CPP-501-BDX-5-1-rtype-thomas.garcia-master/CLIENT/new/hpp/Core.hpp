/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Core
*/

#ifndef CORE_HPP_
#define CORE_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <memory>
#include <vector>
#include "Game.hpp"
#include "Menu.hpp"
#include "Lobby.hpp"
#include "Options.hpp"
#include "Pause.hpp"
#include "state.hpp"
#include "../Network/UdpClient/UdpClient.hpp"
#include "../Network/DataBuffer/DataBuffer.hpp"
#include "./PlayerInfos.hpp"
#include "./Time.hpp"
// #include <SFML/Graphics/Color.hpp>

class Core {
    public:
        Core();
        ~Core();
        void backgroundParallax();
        int start();
        int updateState();
    protected:
        std::shared_ptr<DataBuffer> dataBuffer;
        std::shared_ptr<sf::RenderWindow> _window;
        std::vector<sf::IntRect> _boundsView;
        std::vector<sf::Sprite> _bgSprite;
        std::vector<sf::Texture> _textureView;
        std::shared_ptr<sf::Music> _theme;
        state _status;
        Time timeHandler;
        int fps=60;
        std::shared_ptr<PlayerInfos> playerInfos;
};

#endif /* !ENV_HPP_ */