#ifndef OPTION_HPP_
#define OPTION_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <memory>
#include "../Network/TcpClient/TcpClient.hpp"

class Options {
    public:
        Options(std::shared_ptr<sf::RenderWindow> window);
        ~Options();
        int run(std::shared_ptr<TcpClient> client);
    protected:
    private:
};

#endif /* !OPTION_HPP_ */