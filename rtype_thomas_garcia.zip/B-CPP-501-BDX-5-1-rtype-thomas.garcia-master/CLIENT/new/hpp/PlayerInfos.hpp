/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** playerInfos
*/

#ifndef PLAYERINFOS_HPP_
#define PLAYERINFOS_HPP_

#include <SFML/Graphics/Color.hpp>
#include <string>

typedef struct PlayerInfos_s {
    std::string playerNb;
    std::string playerName;
    sf::Color playerColor;
    std::string serverHost;
    std::string serverPort;
} PlayerInfos;

#endif /* !PLAYERINFOS_HPP_ */
