#ifndef PAUSE_HPP_
#define PAUSE_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <memory>
#include "../Network/TcpClient/TcpClient.hpp"

class Pause {
    public:
        Pause(std::shared_ptr<sf::RenderWindow> window);
        ~Pause();
        int run(std::shared_ptr<TcpClient> client);
    protected:
    private:
};

#endif /* !PAUSE_HPP_ */