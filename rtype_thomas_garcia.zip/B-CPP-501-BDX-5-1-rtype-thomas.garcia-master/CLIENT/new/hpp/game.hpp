#ifndef GAME_HPP_
#define GAME_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <memory>
#include <vector>
#include <SFML/Graphics/Color.hpp>
#include "../Network/UdpClient/UdpClient.hpp"
#include "./PlayerInfos.hpp"
#include "./gameObjects.hpp"

enum class entityType {
    AMISSILE = 31,
    APERSO = 51,
    EMISSILE = 30,
    EPERSO = 50,
};

enum class playerNb { 
    PLAYER1,
    PLAYER2,
    PLAYER3,
    PLAYER4,
};

class Game {
    public:
        Game(std::shared_ptr<sf::RenderWindow> window, std::shared_ptr<DataBuffer> DataBuffer_, std::shared_ptr<PlayerInfos> &playerInfos_);
        ~Game();
        void events(std::shared_ptr<UdpClient> udpClient);
        int run(std::shared_ptr<UdpClient> udpClient);
        void addDrawable(std::string type, std::string ID, std::string spriteName, std::string posX, std::string posY);
        void initEntity(std::string);
        void updateEntity();
        void emissile();
        void aperso();
        void amissile();
        void eperso();
    protected:
        std::shared_ptr<sf::RenderWindow> _window;
        std::vector<sf::RectangleShape> _shapedEntityRA;
        std::vector<sf::CircleShape> _shapedEntityCA;
        std::vector<sf::RectangleShape> _shapedEntityRE;
        std::vector<sf::CircleShape> _shapedEntityCE;
        std::shared_ptr<DataBuffer> dataBuffer;
        std::shared_ptr<PlayerInfos> playerInfos;

        std::vector<entity_t> entities;
        std::vector<text_t> texts;
        std::vector<ui_t> uis;
        entityType _type;
        playerNb _nbPlayer;
        sf::Font font;

        bool tmp = false;
    private:
};

#endif /* !GAME_HPP_ */