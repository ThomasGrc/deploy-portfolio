/*
** EPITECH PROJECT, 2021
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** gameObjects
*/

#ifndef GAMEOBJECTS_HPP_
#define GAMEOBJECTS_HPP_

#include <vector>
#include <SFML/Graphics.hpp>

typedef struct entities_s {
    std::shared_ptr<sf::Texture> texture;
    sf::Sprite sprite;
    std::string name;
    std::string ID;
} entity_t;

typedef struct text_s {
    sf::Text text;
    std::string textString;
    std::string ID;
} text_t;

typedef struct ui_s {
    std::shared_ptr<sf::Texture> texture;
    sf::Sprite sprite;
    std::string name;
    std::string ID;
} ui_t;

#endif /* !GAMEOBJECTS_HPP_ */
