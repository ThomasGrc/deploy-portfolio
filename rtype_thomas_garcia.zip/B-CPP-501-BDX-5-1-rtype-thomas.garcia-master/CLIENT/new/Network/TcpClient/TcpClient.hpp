//
// Created by Victor maurin on 10/11/2020.
//

#ifndef RTYPE_TCPCLIENT_H
#define RTYPE_TCPCLIENT_H

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <mutex>
#include <string>
#include <boost/asio.hpp>
#include <memory>
#include "../DataBuffer/DataBuffer.hpp"

using boost::asio::steady_timer;
using boost::asio::ip::tcp;

class TcpClient : public std::enable_shared_from_this<TcpClient> {
    public:
        TcpClient(boost::asio::io_context& io_context, std::shared_ptr<DataBuffer> dataBuffer);
        void start(tcp::resolver::results_type endpoints);
        void stop();
        void start_read();
        void start_write(std::string msg);

        bool stopped_;
        std::string input_buffer_;
        tcp::socket socket_;
    private:
        void start_connect(tcp::resolver::results_type::iterator endpoint_iter);
        void check_deadline();

        std::shared_ptr<DataBuffer> dataBuffer_;
        tcp::resolver::results_type endpoints_;
        steady_timer heartbeat_timer_;
};

#endif //RTYPE_TCPCLIENT_H
