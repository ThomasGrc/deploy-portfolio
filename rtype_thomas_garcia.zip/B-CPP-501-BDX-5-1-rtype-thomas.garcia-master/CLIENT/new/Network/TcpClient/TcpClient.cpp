#include "TcpClient.hpp"

TcpClient::TcpClient(boost::asio::io_context& io_context, std::shared_ptr<DataBuffer> dataBuffer)
    : stopped_(false),
      socket_(io_context),
      heartbeat_timer_(io_context),
      dataBuffer_(dataBuffer)
{
}

void TcpClient::start(tcp::resolver::results_type endpoints)
{
    // Start the connect actor.
    endpoints_ = endpoints;
    start_connect(endpoints_.begin());
}

void TcpClient::stop()
{
    stopped_ = true;
    boost::system::error_code ignored_ec;
    socket_.close(ignored_ec);
    heartbeat_timer_.cancel();
}

void TcpClient::start_connect(tcp::resolver::results_type::iterator endpoint_iter)
{
    auto handler = [self = shared_from_this()] (const boost::system::error_code& error)
        {
            if (self->stopped_)
                return;

            if (!self->socket_.is_open()) {
                std::cout << "Connect timed out\n";
            } else if (error) {
                std::cout << "Connect error: " << error.message() << "\n";

                self->socket_.close();
            } else {
                std::cout << "Connected" << "\n";

                self->start_read();
            }
        };

    if (endpoint_iter != endpoints_.end()) {
        std::cout << "Trying " << endpoint_iter->endpoint() << "...\n";

        socket_.async_connect(endpoint_iter->endpoint(), handler);
    } else {
        stop();
    }
}

void TcpClient::start_read()
{
    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (self->stopped_)
                return;

            if (!error) {
                std::string line(self->input_buffer_.substr(0, bytes_transferred - 1));
                self->input_buffer_.erase(0, bytes_transferred);

                if (!line.empty())
                {
                    self->dataBuffer_->addReceivedData(line);
                    // std::cout << "Received: " << line << "\n";
                }

                self->start_read();
            } else {
                std::cout << "Error on receive: " << error.message() << "\n";

                self->stop();
            }
        };

    boost::asio::async_read_until(socket_, boost::asio::dynamic_buffer(input_buffer_), '\n', handler);
}

void TcpClient::start_write(std::string msg)
{
    if (stopped_)
        return;

    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (self->stopped_)
                return;

            if (!error) {
                std::cout << "Successfuly sent" << std::endl;
            } else {
                std::cout << "Error on heartbeat: " << error.message() << std::endl;

                self->stop();
            }
        };

    boost::asio::async_write(socket_, boost::asio::buffer(msg), handler);
}