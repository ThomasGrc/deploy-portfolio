/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** DataBuffer
*/

#include "DataBuffer.hpp"

DataBuffer::DataBuffer()
{
}

DataBuffer::~DataBuffer()
{
}

std::vector<std::string> DataBuffer::getReceivedData(void) const
{
    return (receivedData);
}

void DataBuffer::addReceivedData(const std::string &arg)
{
    receivedData.push_back(arg);
}

std::string DataBuffer::popReceivedData(void)
{
    std::string data = receivedData.at(0);
    receivedData.erase(receivedData.begin());
    return data;
}