/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** DataBuffer
*/

#ifndef DATABUFFER_HPP_
#define DATABUFFER_HPP_

#include <vector>
#include <string>
#include <mutex>
#include <condition_variable>

class DataBuffer {
    public:
        DataBuffer();
        ~DataBuffer();

        std::vector<std::string> getReceivedData(void) const;
        void addReceivedData(const std::string&);
        std::string popReceivedData(void);

    private:
        std::vector<std::string> receivedData;
};

#endif /* !DATABUFFER_HPP_ */
