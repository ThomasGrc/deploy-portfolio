//
// Created by Victor maurin on 13/11/2020.
//

#ifndef RTYPE_UDPCLIENT_H
#define RTYPE_UDPCLIENT_H

#include <memory>
#include <iostream>
#include <boost/asio.hpp>
#include "../DataBuffer/DataBuffer.hpp"

using boost::asio::ip::udp;

class UdpClient : public std::enable_shared_from_this<UdpClient> 
{
public:
    UdpClient(boost::asio::io_context &io_context, std::shared_ptr<DataBuffer> dataBuffer_);
    
    void connect(std::string host, std::string port);
    void send(std::string message);
    void receive();
    void stop();

private:
    udp::resolver resolver;
    udp::socket s;
    udp::resolver::results_type endpoints;
    std::shared_ptr<DataBuffer> dataBuffer;
    enum { max_length = 1024 };

    char reply[max_length];
};


#endif //RTYPE_UDPCLIENT_H
