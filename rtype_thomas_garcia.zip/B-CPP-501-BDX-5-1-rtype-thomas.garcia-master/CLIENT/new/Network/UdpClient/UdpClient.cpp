#include "UdpClient.hpp"

using boost::asio::ip::udp;

UdpClient::UdpClient(boost::asio::io_context &io_context, std::shared_ptr<DataBuffer> dataBuffer_) : 
        dataBuffer(dataBuffer_),
        s(udp::socket(io_context, udp::endpoint(udp::v4(), 0))),
        resolver(io_context)
{
}

void UdpClient::connect(std::string host, std::string port)
{
    this->endpoints = udp::resolver::results_type(resolver.resolve(udp::v4(), host, port));
}

void UdpClient::receive() {

    udp::endpoint sender_endpoint;

    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
    {
        if (!error) {
            // std::cout << "message received: " << self->reply << std::endl;
            self->dataBuffer->addReceivedData(std::string(self->reply, bytes_transferred - 1)); // -1 to erase \n
            // std::string line(self->buffer.substr(0, bytes_transferred - 1));
            // if (!line.empty())
            // {
            //     self->dataBuffer_->addReceivedData(line);
            //     // std::cout << "Received: " << line << "\n";
            // }
            self->receive();
        } else {
            std::cout << "Error on receive: " << error.message() << "\n";
            self->stop();
        }
    };
    s.async_receive_from( boost::asio::buffer(this->reply, max_length) , sender_endpoint, handler );
}

void UdpClient::send(std::string message) {

    size_t requestLength = message.size();
    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
    {
        if (!error) {
            // std::cout << "udp message sent" << std::endl;
        } else {
            std::cout << "Error on receive: " << error.message() << "\n";
            self->stop();
        }
    };

    s.async_send_to(boost::asio::buffer(message, requestLength), *endpoints.begin(), handler);
}

void UdpClient::stop() {
    boost::system::error_code ignored_ec;
    s.close(ignored_ec);
}


// int main(int argc, char* argv[])
// {
//     try {
//         boost::asio::io_context io_context;
//         std::shared_ptr<DataBuffer> dataBuffer = std::make_shared<DataBuffer>();
//         std::shared_ptr<UdpClient> client = std::make_shared<UdpClient>(io_context, dataBuffer);
//         client->connect("127.0.0.1", "13");
//         client->send("message");

//         while (true) {
//             client->receive();
//             io_context.poll();
//             if (!dataBuffer->getReceivedData().empty()) {
//                 std::cout << dataBuffer->popReceivedData() << std::endl;
//             }
//         }

//     } catch (std::exception& e) {
//         std::cerr << e.what() << std::endl;
//     }

//   return 0;
// }