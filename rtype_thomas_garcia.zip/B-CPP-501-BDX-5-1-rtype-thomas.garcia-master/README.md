# B-CPP-501-BDX-5-1-rtype-thomas.garcia
An epitech school project consisting of creating a multiplayer client-server r-type game.

### Summary

  - [Setup](#Setup)
  - [Usage](#Usage)

# Setup

# Usage
