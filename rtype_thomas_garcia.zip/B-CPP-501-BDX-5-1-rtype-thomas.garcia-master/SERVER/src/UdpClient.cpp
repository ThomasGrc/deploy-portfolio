#include <iostream>
#include <memory>
#include <boost/array.hpp>
#include <boost/asio.hpp>

using boost::asio::ip::udp;

class UdpClient : public std::enable_shared_from_this<UdpClient>
{
public:
    UdpClient(std::string host, std::string port, boost::asio::io_context &io_context) : s(udp::socket(io_context, udp::endpoint(udp::v4(), 0))),
    resolver(io_context), endpoints(resolver.resolve(udp::v4(), host, port))
    {
    }

    void receive() {
        // char reply[max_length];
        udp::endpoint sender_endpoint;
        // s.receive_from(boost::asio::buffer(reply, max_length), sender_endpoint);
        // return std::string(reply);
    
        auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (!error) {
                std::cout << "message received: " << self->reply << std::endl;
                // std::string line(self->buffer.substr(0, bytes_transferred - 1));

                // if (!line.empty())
                // {
                //     self->dataBuffer_->addReceivedData(line);
                //     // std::cout << "Received: " << line << "\n";
                // }

                self->receive();
            } else {
                std::cout << "Error on receive: " << error.message() << "\n";

                self->stop();
            }
        };
        s.async_receive_from( boost::asio::buffer(this->reply, max_length) , sender_endpoint, handler );
    }

    void send(std::string message) {
        requestLength = message.size();
        auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (!error) {
                std::cout << "message sent" << std::endl;
            } else {
                std::cout << "Error on receive: " << error.message() << "\n";

                self->stop();
            }
        };

        s.async_send_to(boost::asio::buffer(message, requestLength), *endpoints.begin(), handler);
    }

    void stop() {
        boost::system::error_code ignored_ec;
        s.close(ignored_ec);
    }

private:
    udp::resolver resolver;
    udp::socket s;
    udp::resolver::results_type endpoints;
    size_t requestLength;
    enum { max_length = 1024 };

    char reply[max_length];
};

int main(int argc, char* argv[])
{
    try {
        boost::asio::io_context io_context;
        std::shared_ptr<UdpClient> client = std::make_shared<UdpClient>("127.0.0.1", "13", io_context);
        client->send("message");
        client->receive();
        io_context.run();

    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }

  return 0;
}