#include "Game/Game.hpp"
// #include "gameEngine/gameEngine.hpp"

int main()
{
    Game game;
    game.createLobby();
    game.run();
    return 0;
}
