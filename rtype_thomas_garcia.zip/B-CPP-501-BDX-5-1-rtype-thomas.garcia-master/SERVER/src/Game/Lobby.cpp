/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Lobby
*/

#include "Lobby.hpp"

Lobby::Lobby()
{
}

Lobby::~Lobby()
{
}

int Lobby::waitForPlayers()
{
    bool keepGoing = true;
    std::cout << "Lobby wait" << std::endl;
    while (keepGoing) {
        if ( playersCount == playersReady && playersCount > 0)
            keepGoing = false;
        mutex->lock();
        while (!dataBuff->getReceivedData().empty()) {
            std::string rawData = dataBuff->popReceivedData();
            std::cout << "rawData: " << rawData << std::endl;
            size_t pos = rawData.find("-");
            std::string dataType = rawData.substr(0, pos != std::string::npos ? pos : (rawData.length()));
            std::cout << "dataType: " << dataType << std::endl;
            std::string payload = "";
            if (rawData.length() != dataType.length()) {
                rawData.erase(0, dataType.length() + 1); // + 1 to erase the '-' char
                // payload = rawData.substr(0, rawData.find("-"));
                payload = rawData;
            }
            std::cout << "payload: " << "\'" + payload + "\'" << std::endl;
        
            if (dataType == "connected") {
                dataBuff->addDataToSend("connected\n");
            }
            if (dataType == "new") {
                playersCount++; //TODO -> kick if more than 4 players
                dataBuff->addDataToSend("new-" + std::to_string(playersCount) + "-" + payload + "\n");
            }
            if (dataType == "ready") {
                playersReady++; //TODO -> kick if more than 4 players
                std::cout << "\'" + payload + "\'" << std::endl;
                dataBuff->addDataToSend("ready-" + payload + "\n");
            }
        
        }
        mutex->unlock();
        // wait player activity
        // if new connection
        //      increase playerCount
        //      send player/rdy count 
        // if player ready
        //      send rdy count
        server->sendToAll();
        if (io_context->stopped())
            io_context->restart();
        io_context->poll();
    }
    return (countdownBeforeStart());
}

int Lobby::countdownBeforeStart()
{
    // 3 2 1 fade
    return (startGame());
}

int Lobby::startGame()
{
    // TODO
    mutex->lock();
    std::cout << "GAME IS STARTING" << std::endl;
    dataBuff->addDataToSend("starting\n");
    mutex->unlock();
    server->sendToAll();
    io_context->poll();
    return playersCount;
}

void Lobby::playerConnection()
{
}

void Lobby::playerDisconnection()
{
    // return 0 if last player disconnects
}

void Lobby::setDataBuff(const std::shared_ptr<DataBuffer> &arg)
{
    dataBuff = arg;
}

void Lobby::setMutex(const std::shared_ptr<std::mutex> &mutex)
{
    this->mutex = mutex;
}

void Lobby::setServer(const std::shared_ptr<tcp_server> &server)
{
    this->server = server;
}

void Lobby::setIoContext(const std::shared_ptr<boost::asio::io_context> &io_context)
{
    this->io_context = io_context;
}