/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Text
*/

#include "Player.hpp"
#include <iostream>

InputHandler inputHandler;

Player::Player() : Entity()
{
}

Player::Player(double posX, double posY)
    : Entity(posX, posY)
{
}

Player::Player(double posX, double posY, double width, double height)
    : Entity(posX, posY, width, height)
{
}

Player::~Player()
{
}

void Player::start()
{
    this->addActionHandler();
}

void Player::fixedUpdate()
{
    if (actionHandler->isActionRequested(Action::LEFT)) {
        double offset = 50 * timeHandler.getTimeSinceLastFrame();
        this->setPosition(vector2<double>( this->getPosition().x - offset, this->getPosition().y ));
        this->getCollider()->move(vector2<double>( this->getPosition().x - offset, this->getPosition().y ));
    }
    if ( actionHandler->isActionRequested(Action::DOWN) ) {
        double offset = 50 * timeHandler.getTimeSinceLastFrame();
        this->setPosition(vector2<double>( this->getPosition().x, this->getPosition().y + offset ));
        this->getCollider()->move(vector2<double>( this->getPosition().x, this->getPosition().y + offset ));
    }
    if (actionHandler->isActionRequested(Action::UP)) {
        double offset = 50 * timeHandler.getTimeSinceLastFrame();
        this->setPosition(vector2<double>( this->getPosition().x, this->getPosition().y - offset ));
        this->getCollider()->move(vector2<double>( this->getPosition().x, this->getPosition().y - offset));
    }
    if (actionHandler->isActionRequested(Action::RIGHT)) {
        double offset = 50 * timeHandler.getTimeSinceLastFrame();
        // std::cout << offset << std::endl;
        this->setPosition(vector2<double>( this->getPosition().x + offset, this->getPosition().y ));
        this->getCollider()->move(vector2<double>( this->getPosition().x + offset, this->getPosition().y ));
    }
}

// add this in some function to create the entity
// entities.push_back(std::make_shared<Player>())