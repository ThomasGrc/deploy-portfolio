/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Text
*/

#ifndef TEST_HPP_
#define TEST_HPP_

#include "../gameEngine/DataTypes/GameData.hpp"
#include "../gameEngine/Input/InputHandler.hpp"
#include "../gameEngine/Time/Time.hpp"

class Player : public Entity {
    public:
        Player();
        Player(double posX, double posY);
        Player(double posX, double posY, double width, double height);
        ~Player();

        void fixedUpdate();
        void start();
    protected:
    private:
};

#endif /* !TEST_HPP_ */
