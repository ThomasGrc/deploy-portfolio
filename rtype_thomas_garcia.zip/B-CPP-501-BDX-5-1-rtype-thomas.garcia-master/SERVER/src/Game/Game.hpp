/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Game
*/

#ifndef GAME_HPP_
#define GAME_HPP_

#include <memory>
#include <mutex>
#include "../Network/TcpServer/TcpServer.hpp"
#include "../Network/DataBuffer/DataBuffer.hpp"
#include "../gameEngine/gameEngine.hpp"
#include "./Player.hpp"
#include "Lobby.hpp"

// class Lobby;

class Game {
    public:
        Game();
        ~Game();

        void createLobby();
        void run();
        int getPlayersCount() const;
        void setPlayersCount(const int arg);
        std::shared_ptr<DataBuffer> getTcpDataBuffer(void) const;
    protected:
    private:
        std::shared_ptr<std::mutex> mutex;
        std::shared_ptr<boost::asio::io_context> io_context;
        Lobby gameLobby;
        int nbPlayersConnected=0;
        std::shared_ptr<DataBuffer> tcpDataBuffer;
        std::shared_ptr<tcp_server> server;
};

#endif /* !GAME_HPP_ */
