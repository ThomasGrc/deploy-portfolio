/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Lobby
*/

#ifndef LOBBY_HPP_
#define LOBBY_HPP_

#include <memory>
#include <iostream>//tmp
#include <mutex>
#include "../Network/DataBuffer/DataBuffer.hpp"
#include "../Network/TcpServer/TcpServer.hpp"

class Lobby {
    public:
        Lobby();
        ~Lobby();

        int waitForPlayers();
        int countdownBeforeStart();
        int startGame();
        void playerConnection();
        void playerDisconnection();

        void setMutex(const std::shared_ptr<std::mutex> &mutex);
        void setDataBuff(const std::shared_ptr<DataBuffer> &arg);
        void setServer(const std::shared_ptr<tcp_server> &server);
        void setIoContext(const std::shared_ptr<boost::asio::io_context> &io_context);

    protected:
    private:
        int playersCount=0;
        int playersReady=0;
        std::shared_ptr<boost::asio::io_context> io_context;
        std::shared_ptr<std::mutex> mutex;
        std::shared_ptr<DataBuffer> dataBuff;
        std::shared_ptr<tcp_server> server;
};

#endif /* !LOBBY_HPP_ */
