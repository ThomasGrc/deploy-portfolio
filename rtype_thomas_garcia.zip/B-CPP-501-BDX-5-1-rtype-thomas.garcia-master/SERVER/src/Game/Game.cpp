/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Game
*/

#include "Game.hpp"

Game::Game()
{
    mutex = std::make_shared<std::mutex>();
    gameLobby.setMutex(mutex);
    // gameLobby = std::weak_ptr<Lobby>();
    tcpDataBuffer = std::make_shared<DataBuffer>();
    io_context = std::make_shared<boost::asio::io_context>();
    server = std::make_shared<tcp_server>(io_context, tcpDataBuffer, mutex);
    gameLobby.setServer(server);
    gameLobby.setDataBuff(tcpDataBuffer);
    gameLobby.setIoContext(io_context);
    std::cout << "game created "<< std::endl;
}

Game::~Game()
{
}

void Game::createLobby()
{
    mutex->lock();
    std::cout << "Lobby created "<< std::endl;
    mutex->unlock();
    this-> nbPlayersConnected = gameLobby.waitForPlayers();
    //stop io_context with mutex
}

int Game::getPlayersCount() const
{
    return (nbPlayersConnected);
}

void Game::setPlayersCount(const int arg)
{
    nbPlayersConnected = arg;
}

std::shared_ptr<DataBuffer> Game::getTcpDataBuffer(void) const
{
    return (tcpDataBuffer);
}

void Game::run()
{
    Core gameEngine;

    for (size_t i = 0; i < this->nbPlayersConnected; i++) {
        std::shared_ptr<Entity> player = std::make_shared<Player>(50, 100 * (i + 1), 10, 10);
        player->setName("Player" + std::to_string(i + 1));

        player->start();
        gameEngine.addPlayer(player->getID());
        entities.push_back(player);
    }

    gameEngine.fps = 20;
    gameEngine.loop();
}