/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** gameEngine
*/

#ifndef GAMEENGINE_BASE_HPP_
#define GAMEENGINE_BASE_HPP_

#include "Core/Core.hpp"
#include "Colliders/SpriteCollider.hpp"
#include "Colliders/UICollider.hpp"
// #include "CollisionDetection/Collision.hpp"
#include "DataTypes/GameData.hpp"
#include "DataTypes/rectangle.hpp"
#include "DataTypes/vector2.hpp"
#include "DataTypes/vector3.hpp"
#include "Entity/Entity.hpp"
// #include "Input/Input.hpp"
// #include "Input/InputHandler.hpp"
#include "ScriptableElement/ScriptableElement.hpp"
#include "TextElement/TextElement.hpp"
#include "Time/Time.hpp"
#include "UIElement/UIElement.hpp"

#endif /* !GAMEENGINE_BASE_HPP_ */
