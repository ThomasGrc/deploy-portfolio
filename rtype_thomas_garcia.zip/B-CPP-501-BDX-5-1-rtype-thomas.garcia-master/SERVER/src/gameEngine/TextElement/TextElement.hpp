/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Text
*/

#ifndef TEXTELEMENT_HPP_
#define TEXTELEMENT_HPP_

#include <string>
#include <memory>
#include <uuid/uuid.h>
#include "../Time/Time.hpp"
#include "../Colliders/UICollider.hpp"
#include "../DataTypes/rectangle.hpp"
#include "../DataTypes/vector2.hpp"
#include "../DataTypes/GameData.hpp"

using namespace std;

//!
//! Base class for any text element
//!
class TextElement {
    public:
        TextElement();
        ~TextElement();

        // =================================================================
                            /* ----- METHODS ----- */
        // =================================================================
        //!
        //! Called upon game start
        //!
        virtual void start();
        //!
        //! Called inside game loop (on non a regular time line)
        //!
        virtual void update();
        //!
        //! Called inside game loop (on a regular time line)
        //!
        virtual void fixedUpdate();
        //!
        //! Called when the text is clicked on
        //! click   The position at which the click occured
        //!
        virtual void onClick(vector2<double> click);

        // =================================================================
                            /* ----- GETTERS ----- */
        // =================================================================
        //!
        //! returns true of the entity has a collider
        //!
        bool hasCollider(void) const;
        string getID(void) const;
        shared_ptr<UICollider> getCollider(void) const;
        vector2<double> getPosition(void) const;
        string getName(void) const;
        string getText(void) const;

        // =================================================================
                            /* ----- SETTERS ----- */
        // =================================================================
        void setCollider(const shared_ptr<UICollider>&);
        void setPosition(const vector2<double>&);
        void setName(const string&);
        void setText(const string&);

    protected:
        // =================================================================
                            /* ---- VARIABLES ---- */
        // =================================================================
        //!
        //! unique ID associated with that specific text element
        //!
        string id = "";
        shared_ptr<UICollider> collider;
        vector2<double> position = {0.0, 0.0};
        string name = "";
        /**
         * @brief   text to display
        */
        string text = "";
};

#endif /* !TEXTELEMENT_HPP_ */
