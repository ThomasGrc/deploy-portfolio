/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** SpriteCollider
*/

#ifndef SPRITECOLLIDER_HPP_
#define SPRITECOLLIDER_HPP_

#include "../DataTypes/rectangle.hpp"
#include "../DataTypes/vector2.hpp"

//!
//! 2D collider class. 
//! Any Entity class that has a ptr to an instance of this SpriteCollider class will be able to collide with
//! other Entity classes if they have an ptr to an instance of that class as well. 
//! This class should not mother any subclasses nor should any class inherit or overload this SpriteCollider class.
//!

class SpriteCollider {
    public:
        SpriteCollider();
        //!
        //!   Constructor overload 
        //!   rect  A rectangle representing the collider size and position
        //!
        SpriteCollider(rectangle<double> rect);
        ~SpriteCollider();

        //!
        //!   Called upon movement of UI classes classes that have a ptr to an instance of this class
        //!   newPos  The new position of the UIElement or Text element that the collider is associated with
        //!
        void move(const vector2<double> &newPos); // called upon movement of Entity classes that have a ptr to an instance of this class
    
        rectangle<double> getRect(void) const;
        void setRect(const rectangle<double>);
    
    private:
        //!
        //!    rectangle data type representing the position and size of the collider
        //!
        rectangle<double> rect;
};

#endif /* !SPRITECOLLIDER_HPP_ */
