/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** SpriteCollider
*/

#include "SpriteCollider.hpp"

SpriteCollider::SpriteCollider()
{
}

SpriteCollider::SpriteCollider(rectangle<double> rect)
{
    this->rect = rect;
}

SpriteCollider::~SpriteCollider()
{
}

void SpriteCollider::move(const vector2<double> &newPos)
{
    rect.x = newPos.x;
    rect.y = newPos.y;
}

rectangle<double> SpriteCollider::getRect(void) const
{
    return (rect);
}

void SpriteCollider::setRect(const rectangle<double> arg)
{
    rect = arg;
}