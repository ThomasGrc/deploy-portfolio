/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** UICollider
*/

#include "UICollider.hpp"

UICollider::UICollider()
{
}

UICollider::UICollider(rectangle<double> &rect)
{
    this->rect = rect;
}

UICollider::~UICollider()
{
}


void UICollider::move(const vector2<double> &newPos)
{
    rect.x = newPos.x;
    rect.y = newPos.y;
}

rectangle<double> UICollider::getRect(void) const
{
    return (rect);
}

void UICollider::setRect(const rectangle<double> &arg)
{
    rect = arg;
}