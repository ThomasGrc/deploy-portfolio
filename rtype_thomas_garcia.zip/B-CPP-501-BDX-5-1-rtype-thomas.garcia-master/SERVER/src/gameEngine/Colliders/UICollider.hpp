/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** UICollider
*/

#ifndef UICOLLIDER_HPP_
#define UICOLLIDER_HPP_

#include "../DataTypes/rectangle.hpp"
#include "../DataTypes/vector2.hpp"

//!
//!  2D text / UI element collider class ; 
//!  Any UI element or text class that has a ptr to an instance of this UICollider class will be able to detect mouse clicks ;
//! This class should not mother any subclasses nor should any class inherit or overload this SpriteCollider class ;
//!
class UICollider {
    public:
        UICollider();

        //!
        //! Constructor overload
        //! rect  A rectangle representing the collider size and position
        //!
        UICollider(rectangle<double> &rect);

        //!
        //! Destructor of class UICollider
        //!
        ~UICollider();

        //!
        //! Called upon movement of UI classes classes that have a ptr to an instance of this class
        //! newPos  The new position of the UIElement or Text element that the collider is associated with
        //!
        void move(const vector2<double> &newPos);

        rectangle<double> getRect(void) const;
        void setRect(const rectangle<double>&);

    private:
        //!
        //! rectangle data type representing the position and size of the collider
        //!
        rectangle<double> rect;
};

#endif /* !UICOLLIDER_HPP_ */
