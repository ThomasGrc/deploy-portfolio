/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** ScriptableObject
*/

#ifndef SCRIPTABLEELEMENT_HPP_
#define SCRIPTABLEELEMENT_HPP_

#include "../Time/Time.hpp"

//!
//! this class is ment to be overloaded and used for any code that cannot be written somewhere else
//!
class ScriptableElement {
    public:
        //!
        //! Constructor of class
        //!
        ScriptableElement();

        //!
        //! Destructor of class
        //!
        ~ScriptableElement();

        //!
        //! Called upon game start
        //!
        void start();

        //!
        //! called inside game loop (on non a regular time line)
        //!
        void update();

        //!
        //! called inside game loop (on a regular time line)
        //!
        void fixedUpdate();

    protected:
    private:
};

#endif /* !SCRIPTABLEELEMENT_HPP_ */
