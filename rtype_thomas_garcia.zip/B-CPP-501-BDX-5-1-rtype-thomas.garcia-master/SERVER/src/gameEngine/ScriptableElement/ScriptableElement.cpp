/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** ScriptableObject
*/

#include "ScriptableElement.hpp"

ScriptableElement::ScriptableElement()
{
    start();
}

ScriptableElement::~ScriptableElement()
{
}

// called upon game start
void ScriptableElement::start()
{
}

// called inside game loop (on non a regular time line)
void ScriptableElement::update()
{
}

// called inside game loop (on a regular time line)
void ScriptableElement::fixedUpdate()
{
}