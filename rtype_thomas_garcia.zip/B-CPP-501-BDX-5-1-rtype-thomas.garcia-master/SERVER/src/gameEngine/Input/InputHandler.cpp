/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Input
*/

#include "InputHandler.hpp"

InputHandler::InputHandler()
{
}

InputHandler::~InputHandler()
{
}

bool InputHandler::isKeyPressed(Input::Key input)
{
    if (keyMap[input])
        return true;
    return false;
}

bool InputHandler::isMouseDown(Input::Mouse input)
{
    if (mouseMap[input])
        return true;
    return false;
}