/*
** EPITECH PROJECT, 2021
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** ActionHandler
*/

#include "ActionHandler.hpp"

ActionHandler::ActionHandler()
{
    this->actionMap = {
        {Action::FORWARD, false},
        {Action::BACKWARD, false},
        {Action::UP, false},
        {Action::DOWN, false},
        {Action::LEFT, false},
        {Action::RIGHT, false},
        {Action::JUMP, false},
        {Action::SHOOT, false}
    };
}

ActionHandler::~ActionHandler()
{
}

bool ActionHandler::isActionRequested(Action requested)
{
    if (actionMap[requested])
        return true;
    return false;
}