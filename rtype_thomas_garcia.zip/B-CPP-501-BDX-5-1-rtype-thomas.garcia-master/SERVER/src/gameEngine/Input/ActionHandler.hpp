/*
** EPITECH PROJECT, 2021
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** ActionHandler
*/

#ifndef ACTIONHANDLER_HPP_
#define ACTIONHANDLER_HPP_

#include <map>
#include <unordered_map>
#include <string>

enum class Action {
    FORWARD,
    BACKWARD,
    UP,
    DOWN,
    LEFT,
    RIGHT,
    JUMP,
    SHOOT
};

static std::map<std::string, Action> ActionStrToEnum = {
   {"FORWARD", Action::FORWARD},
   {"BACKWARD", Action::BACKWARD},
   {"UP", Action::UP},
   {"DOWN", Action::DOWN},
   {"LEFT", Action::LEFT},
   {"RIGHT", Action::RIGHT},
   {"JUMP", Action::JUMP},
   {"SHOOT", Action::SHOOT}
};

class ActionHandler {
    public:
        ActionHandler();
        ~ActionHandler();

        bool isActionRequested(Action requested);
        std::map<Action, bool> actionMap;
    protected:
    private:
};

#endif /* !ACTIONHANDLER_HPP_ */
