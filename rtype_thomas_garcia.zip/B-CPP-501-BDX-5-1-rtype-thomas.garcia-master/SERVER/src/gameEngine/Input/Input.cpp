/*
** EPITECH PROJECT, 2021
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Input
*/

#include "Input.hpp"

std::map<Input::Key, bool> keyMap = {
    {Input::Key::A, false},
    {Input::Key::B, false},
    {Input::Key::C, false},
    {Input::Key::D, false},
    {Input::Key::E, false},
    {Input::Key::F, false},
    {Input::Key::G, false},
    {Input::Key::H, false},
    {Input::Key::I, false},
    {Input::Key::J, false},
    {Input::Key::K, false},
    {Input::Key::L, false},
    {Input::Key::M, false},
    {Input::Key::N, false},
    {Input::Key::O, false},
    {Input::Key::P, false},
    {Input::Key::Q, false},
    {Input::Key::R, false},
    {Input::Key::S, false},
    {Input::Key::T, false},
    {Input::Key::U, false},
    {Input::Key::V, false},
    {Input::Key::W, false},
    {Input::Key::X, false},
    {Input::Key::Y, false},
    {Input::Key::Z, false},
    {Input::Key::NUM_1, false},
    {Input::Key::NUM_2, false},
    {Input::Key::NUM_3, false},
    {Input::Key::NUM_4, false},
    {Input::Key::NUM_5, false},
    {Input::Key::NUM_6, false},
    {Input::Key::NUM_7, false},
    {Input::Key::NUM_8, false},
    {Input::Key::NUM_9, false},
    {Input::Key::NUM_0, false},
    {Input::Key::MAJ_R, false},
    {Input::Key::MAJ_L, false},
    {Input::Key::CTRL, false},
    {Input::Key::TAB, false},
    {Input::Key::ARROW_R, false},
    {Input::Key::ARROW_L, false},
    {Input::Key::ARROW_UP, false},
    {Input::Key::ARROW_DOWN, false},
    {Input::Key::SPACE, false}
};

std::map<Input::Mouse, bool> mouseMap = {
    {Input::Mouse::BTN_1, false},
    {Input::Mouse::BTN_2, false},
    {Input::Mouse::BTN_3, false},
    {Input::Mouse::BTN_4, false},
    {Input::Mouse::BTN_5, false},
    {Input::Mouse::BTN_6, false},
    {Input::Mouse::BTN_7, false}
};

// Input::Input()
// {
// }

// Input::~Input()
// {
// }
