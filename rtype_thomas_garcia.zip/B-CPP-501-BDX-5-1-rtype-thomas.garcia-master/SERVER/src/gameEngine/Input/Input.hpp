/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Input
*/

#ifndef INPUT_HPP_
#define INPUT_HPP_

#include <map>
#include <unordered_map>
#include <string>

namespace Input {
    enum class Key {
        A,
        B,
        C,
        D,
        E,
        F,
        G,
        H,
        I,
        J,
        K,
        L,
        M,
        N,
        O,
        P,
        Q,
        R,
        S,
        T,
        U,
        V,
        W,
        X,
        Y,
        Z,
        NUM_1,
        NUM_2,
        NUM_3,
        NUM_4,
        NUM_5,
        NUM_6,
        NUM_7,
        NUM_8,
        NUM_9,
        NUM_0,
        MAJ_R,
        MAJ_L,
        CTRL,
        TAB,
        ARROW_R,
        ARROW_L,
        ARROW_UP,
        ARROW_DOWN,
        SPACE
    };

    enum class Mouse {
        BTN_1,
        BTN_2,
        BTN_3,
        BTN_4,
        BTN_5,
        BTN_6,
        BTN_7,
    };
};

static std::map<std::string, Input::Key> keyStrToEnum = {
    {"A", Input::Key::A},
    {"B", Input::Key::B},
    {"C", Input::Key::C},
    {"D", Input::Key::D},
    {"E", Input::Key::E},
    {"F", Input::Key::F},
    {"G", Input::Key::G},
    {"H", Input::Key::H},
    {"I", Input::Key::I},
    {"J", Input::Key::J},
    {"K", Input::Key::K},
    {"L", Input::Key::L},
    {"M", Input::Key::M},
    {"N", Input::Key::N},
    {"O", Input::Key::O},
    {"P", Input::Key::P},
    {"Q", Input::Key::Q},
    {"R", Input::Key::R},
    {"S", Input::Key::S},
    {"T", Input::Key::T},
    {"U", Input::Key::U},
    {"V", Input::Key::V},
    {"W", Input::Key::W},
    {"X", Input::Key::X},
    {"Y", Input::Key::Y},
    {"Z", Input::Key::Z},
    {"NUM_1", Input::Key::NUM_1},
    {"NUM_2", Input::Key::NUM_2},
    {"NUM_3", Input::Key::NUM_3},
    {"NUM_4", Input::Key::NUM_4},
    {"NUM_5", Input::Key::NUM_5},
    {"NUM_6", Input::Key::NUM_6},
    {"NUM_7", Input::Key::NUM_7},
    {"NUM_8", Input::Key::NUM_8},
    {"NUM_9", Input::Key::NUM_9},
    {"NUM_0", Input::Key::NUM_0},
    {"MAJ_R", Input::Key::MAJ_R},
    {"MAJ_L", Input::Key::MAJ_L},
    {"CTRL", Input::Key::CTRL},
    {"TAB", Input::Key::TAB},
    {"ARROW_R", Input::Key::ARROW_R},
    {"ARROW_L", Input::Key::ARROW_L},
    {"ARROW_UP", Input::Key::ARROW_UP},
    {"ARROW_DOWN", Input::Key::ARROW_DOWN},
    {"SPACE", Input::Key::SPACE}
};

static std::map<std::string, Input::Mouse> MouseStrToEnum = {
    {"BTN_1", Input::Mouse::BTN_1},
    {"BTN_2", Input::Mouse::BTN_2},
    {"BTN_3", Input::Mouse::BTN_3},
    {"BTN_4", Input::Mouse::BTN_4},
    {"BTN_5", Input::Mouse::BTN_5},
    {"BTN_6", Input::Mouse::BTN_6},
    {"BTN_7", Input::Mouse::BTN_7}
};

extern std::map<Input::Key, bool> keyMap;

extern std::map<Input::Mouse, bool> mouseMap;

#endif /* !INPUT_HPP_ */
