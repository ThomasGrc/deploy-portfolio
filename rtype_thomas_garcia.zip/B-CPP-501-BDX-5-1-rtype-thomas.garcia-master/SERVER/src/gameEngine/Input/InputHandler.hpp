/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Input
*/

#ifndef INPUTHANDLER_HPP_
#define INPUTHANDLER_HPP_

#include "Input.hpp"

class InputHandler {
    public:
        //!
        //! Constructor of class InputHandler
        //!
        InputHandler();

        //!
        //! Destructor of class InputHandler
        //!
        ~InputHandler();

        //!
        //! Return true if Input::key is Pressed
        //!
        bool isKeyPressed(Input::Key input);

        //!
        //! Return true if Input::Mouse is clicked
        //!
        bool isMouseDown(Input::Mouse input);
};

extern InputHandler inputHandler;

#endif /* !INPUTHANDLER_HPP_ */
