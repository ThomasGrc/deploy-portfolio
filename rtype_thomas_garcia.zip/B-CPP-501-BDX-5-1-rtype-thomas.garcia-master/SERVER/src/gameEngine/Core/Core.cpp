/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Core
*/

#include <iostream>
#include "Core.hpp"

//extern variables
Time timeHandler;
queue<std::string> freeIDs;
int lastID;
vector<shared_ptr<Entity>> entities;
vector<shared_ptr<TextElement>> textElements;
vector<shared_ptr<UIElement>> uiElements;
vector<shared_ptr<ScriptableElement>> scripts;

Core::Core()
{
    this->nbPlayersConnected = 0;
    this->dataBuffer = std::make_shared<DataBuffer>();
    this->udp = std::make_shared<UdpServer>(io_context, this->dataBuffer);
    udp->recv();
}

Core::~Core()
{
}

// creates a new threaded game in case of a multiplayer game
void Core::createRoom()
{
    // TODO
}

// Calls the update method of every game classes
void Core::update()
{
    collisionHandler.AddAll(entities);
    collisionHandler.SearchAll(entities);

    for (size_t i = 0; i < scripts.size(); i++) {
        scripts[i]->update();
    }
    for (size_t i = 0; i < entities.size(); i++) {
        entities[i]->update();
    }
    for (size_t i = 0; i < textElements.size(); i++) {
        textElements[i]->update();
    }
    for (size_t i = 0; i < uiElements.size(); i++) {
        uiElements[i]->update();
    }
}

// Calls the fixedUpdate method of every game classes
void Core::fixedUpdate()
{
    for (size_t i = 0; i < scripts.size(); i++) {
        scripts[i]->fixedUpdate();
    }
    for (size_t i = 0; i < entities.size(); i++) {
        entities[i]->fixedUpdate();
    }
    for (size_t i = 0; i < textElements.size(); i++) {
        textElements[i]->fixedUpdate();
    }
    for (size_t i = 0; i < uiElements.size(); i++) {
        uiElements[i]->fixedUpdate();
    }
}

// Receives data from client(s) and updates data structures (inputs, actions, ...) depending on what was received
void Core::receiveData()
{
    this->io_context.poll();
    while (!this->dataBuffer->getReceivedData().empty()) {
        std::string rawData = this->dataBuffer->popReceivedData();
        // std::cout << "received : " << rawData << std::endl;

        if (rawData != "connection") {
            // get instruction
            std::string dataType = rawData.substr(0, rawData.find("-"));
            rawData.erase(0, dataType.length() + 1);
            // get player nb
            int playerNb = std::atoi(rawData.substr(0, rawData.find("-")).c_str()) - 1;
            rawData.erase(0, rawData.substr(0, rawData.find("-")).length() + 1);
            // find entity corresponding to player
            size_t playerIndex = 0;
            for (playerIndex = 0; playerIndex < entities.size(); playerIndex++) {
                if (entities[playerIndex]->getID() == playerIds[playerNb])
                    break;
            }

            if (dataType == "action") {
                std::string key = rawData.substr(0, rawData.find("-"));
                rawData.erase(0, key.length() + 1);
                std::string state = rawData;
                if (state == "pressed") {
                    entities[playerIndex]->getActionHandler()->actionMap.at( ActionStrToEnum.at(key) ) = true;
                } else if (state == "released") {
                    entities[playerIndex]->getActionHandler()->actionMap.at( ActionStrToEnum.at(key) ) = false;
                }
            }
        }
    }
}

// Sends data back to the client(s) after processing the updates
void Core::sendData()
{
    for (size_t i = 0; i < entities.size(); i++) {
        this->dataBuffer->addDataToSend(*(entities[i].get()));
    }
    for (size_t i = 0; i < textElements.size(); i++) {
        this->dataBuffer->addDataToSend(*(textElements[i].get()));
    }
    for (size_t i = 0; i < uiElements.size(); i++) {
        this->dataBuffer->addDataToSend(*(uiElements[i].get()));
    }

    while (!this->dataBuffer->getDataToSend().empty()) {
        std::string msg = this->dataBuffer->popDataToSend();
        // std::cout << "sending " << msg << std::endl;
        this->udp->send(msg);
    }
    this->io_context.poll();
}

// game update loop
void Core::loop()
{
    /* pseudo code */

    // while(Running())
    // {
        // var begin = current_time();
        // receive_from_clients(); // poll, accept, receive, decode, validate
        // update(); // AI, simulate
        // send_updates_clients();
        // var elapsed = current_time() - begin;
        // if(elapsed < tick)
        // {
            // sleep(tick - elapsed);
        // }
    // }

    double frameTime = 1.0f / this->fps;
    double remainingTime = 0.0;
    double totalTime = 0.0;
    size_t updates = 0;
    int trueFps = 0;

    while (isRunning) {

        timeHandler.frameBgnTime = timeHandler.getTime();

        trueFps++;
        // TODO recv inputs, ... from clients
        receiveData();
        update();
        fixedUpdate();
        // TODO send updates to client
        sendData();

        // if the remaining time is > to the time of 1 frame, keep updating the game
        // this fixes the framerate at $fps frames per sec without using sleep() to prevent lags at low fps
        remainingTime = frameTime - timeHandler.getDeltaTime();
        updates = 0;
        if (timeHandler.getDeltaTime() < remainingTime) {
            timeHandler.updateBgnTime = timeHandler.getTime();
            while (timeHandler.getUpdateDeltaTime() < remainingTime) {
                timeHandler.updateBgnTime = timeHandler.getTime();
                // if (updates < 5) {
                update();
                updates++;
                // }
                remainingTime -= timeHandler.getUpdateDeltaTime();
            }
        }
        collisionHandler.DeleteAll();
        timeHandler.totalFrameTime = 0;
        timeHandler.totalFrameTime += frameTime - remainingTime;
        // just to print the fps count every sec
        totalTime += frameTime - remainingTime;
        if (totalTime >= 1) {
            std::cout << "fps: " << trueFps << std::endl;
            totalTime = 0;
            trueFps = 0;
        }
    }
}

void Core::addPlayer(std::string id)
{
    this->nbPlayersConnected++;
    this->playerIds.push_back(id);
}