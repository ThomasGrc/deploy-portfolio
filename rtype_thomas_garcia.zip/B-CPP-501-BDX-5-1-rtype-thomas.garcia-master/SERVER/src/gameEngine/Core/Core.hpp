/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Core
*/

#ifndef CORE_HPP_
#define CORE_HPP_

#include <vector>
#include <ctime>
#include <memory>
// #include <unordered_map>
#include "../Time/Time.hpp"
#include "../Entity/Entity.hpp"
#include "../UIElement/UIElement.hpp"
#include "../TextElement/TextElement.hpp"
#include "../ScriptableElement/ScriptableElement.hpp"
#include "../CollisionDetection/Collision.hpp"
#include "../UdpServer/UdpServer.hpp"
#include "../DataBuffer/DataBuffer.hpp"
#include "../Input/InputHandler.hpp"
#include "../Input/ActionHandler.hpp"

using namespace std;

//!
//! The main class from which the game engine is piloted
//!
class Core
{
    public:
        Core();
        ~Core();

        // =================================================================
                            /* ----- METHODS ----- */
        // =================================================================
        //!
        //! Creates a new threaded game in case of a multiplayer game
        //!

        void createRoom();

        //!
        //! Game update loop. Recives date from the client(s) in case of server - client multiplayer game, 
        //! runs the updates and sends data back to the client if needed.
        //!

        void loop();

        //!
        //! Calls the update method of every game classes
        //!

        void update();

        //!
        //! Calls the fixedUpdate method of every game classes
        //!

        void fixedUpdate();

        //!
        //! Receives data from client(s) and updates data structures (inputs, ...) depending on what was received
        //!

        void receiveData();
        
        //!
        //! Sends data back to the client(s) after processing the updates
        //!
        void sendData();

        void addPlayer(std::string id);
        // =================================================================
                            /* ---- VARIABLES ---- */
        // =================================================================
        int fps = 60;
    private:
        bool isRunning = true;
        Collision collisionHandler;
        boost::asio::io_context io_context;
        std::shared_ptr<UdpServer> udp;
        std::shared_ptr<DataBuffer> dataBuffer;
        int nbPlayersConnected;
        std::vector<std::string> playerIds;
};

#endif /* !CORE_HPP_ */
