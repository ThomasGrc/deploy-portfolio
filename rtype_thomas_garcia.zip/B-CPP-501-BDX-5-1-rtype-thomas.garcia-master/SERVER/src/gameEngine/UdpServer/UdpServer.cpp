// #include <iostream>
// #include <memory>
// #include <boost/array.hpp>
// #include <boost/asio.hpp>
#include "UdpServer.hpp"

using boost::asio::ip::udp;

UdpServer::UdpServer(boost::asio::io_context& io_context, std::shared_ptr<DataBuffer> dataBuffer_)
        : socket_(io_context, udp::endpoint(udp::v4(), 13)),
        dataBuffer(dataBuffer_)
{
}

void UdpServer::recv() {
    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (!error) {
                // std::cout << "message received: " << self->message << std::endl;
                self->dataBuffer->addReceivedData(std::string(self->message, bytes_transferred - 1)); // -1 to erase \n
                bool present = false;
                for(udp::endpoint endpoint : self->endpoints) {
                    if (endpoint == self->remote_endpoint_)
                        present = true;
                }
                if (!present)
                    self->endpoints.push_back(self->remote_endpoint_);
                self->recv();
            } else {
                std::cout << "Error on receive: " << error.message() << "\n";
                // self->stop();
            }
        };

    socket_.async_receive_from(boost::asio::buffer(message, max_length), remote_endpoint_, handler);
}

void UdpServer::send(std::string message) {

    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (!error) {
                // std::cout << "udp: message sent" << std::endl;
            } else {
                std::cout << "Error on receive: " << error.message() << "\n";
                // self->stop();
            }
        };

    for (udp::endpoint endpoint : this->endpoints) {
        socket_.async_send_to(boost::asio::buffer(message), endpoint, handler);
    }
}

// int main()
// {
//     try
//     {
//         std::shared_ptr<DataBuffer> dataBuffer = std::make_shared<DataBuffer>();
//         boost::asio::io_service io_service;
//         std::shared_ptr<UdpServer> server = std::make_shared<UdpServer>(io_service, dataBuffer);

//         while (true) {
//             server->recv();
//             io_service.run();
//             if (!dataBuffer->getReceivedData().empty()) {
//                 std::cout << dataBuffer->popReceivedData() << std::endl;
//             }
//         }
//     }
//     catch (std::exception& e)
//     {
//         std::cerr << e.what() << std::endl;
//     }

//     return 0;
// }