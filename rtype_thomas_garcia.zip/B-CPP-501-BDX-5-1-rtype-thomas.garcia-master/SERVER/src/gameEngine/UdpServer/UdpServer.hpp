#include <boost/asio.hpp>
#include <boost/array.hpp>
#include <memory>
#include <iostream>
#include <vector>
#include "../DataBuffer/DataBuffer.hpp"

using boost::asio::ip::udp;


class UdpServer : public std::enable_shared_from_this<UdpServer>
{
public:
    UdpServer(boost::asio::io_context& io_context, std::shared_ptr<DataBuffer> dataBuffer_);
    void recv();
    void send(std::string msg);
private:
    udp::socket socket_;
    udp::endpoint remote_endpoint_;
    std::vector<udp::endpoint> endpoints;
    std::shared_ptr<DataBuffer> dataBuffer;
    enum { max_length = 1024 };

    char message[max_length];
};
