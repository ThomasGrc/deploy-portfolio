/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** main
*/

#include <stdio.h>
#include <memory>
#include "Core/Core.hpp"
#include "../Game/Player.hpp"

int main()
{
    Core ge;

    std::shared_ptr<Entity> test = std::make_shared<Player>();
    test->setCollider(std::make_shared<SpriteCollider>(rectangle<double>(-10, -10, 0, 0)));
    entities.push_back(test);

    ge.fps = 20;
    ge.loop();
    return 0;
}