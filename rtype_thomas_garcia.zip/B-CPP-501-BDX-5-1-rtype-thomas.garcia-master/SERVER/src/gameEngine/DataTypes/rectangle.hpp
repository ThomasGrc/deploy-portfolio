/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** rect
*/

#ifndef RECTANGLE_HPP_
#define RECTANGLE_HPP_

template <typename T>
class rectangle {
    public:
        //!
        //! Constructor of class rectangle
        //!
        rectangle();

        //!
        //! Overload of constructor
        //!
        rectangle(T width, T height);

        //!
        //! Overload of constructor
        //!
        rectangle(T x, T y, T width, T height);

        //!
        //! Destructor of class rectangle
        //!
        ~rectangle();

        rectangle<T>& operator=(const rectangle<T>& other);
        bool operator==(const rectangle<T>& other) const;

        T x;
        T y;
        T width;
        T height;
};

template <typename T>
rectangle<T>::rectangle() 
{
    x = 0;
    y = 0;
    width = 0;
    height = 0;
}

template <typename T>
rectangle<T>::~rectangle() {}

template <typename T>
rectangle<T>::rectangle(T width, T height) 
{
    x = 0;
    y = 0;
    this->width = width;
    this->height = height;
}

template <typename T>
rectangle<T>::rectangle(T x, T y, T width, T height) 
{
    this->x = x;
    this->y = y;
    this->width = width;
    this->height = height;
}

template <typename T>
rectangle<T>& rectangle<T>::operator=(const rectangle<T>& other)
{
    x = other.x;
    y = other.y;
    width = other.width;
    height = other.height;
    return (*this);
}

template <typename T>
bool rectangle<T>::operator==(const rectangle<T>& other) const
{
    return (x == other.x && y == other.y && width == other.width && height == other.height);
}

#endif /* !RECTANGLE_HPP_ */
