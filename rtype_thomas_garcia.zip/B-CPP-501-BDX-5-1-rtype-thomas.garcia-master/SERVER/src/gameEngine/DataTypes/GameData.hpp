/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** GameData
*/

#ifndef GAMEDATA_HPP_
#define GAMEDATA_HPP_

#include <vector>
#include <memory>
#include <queue>
#include "../Entity/Entity.hpp"
#include "../UIElement/UIElement.hpp"
#include "../TextElement/TextElement.hpp"
#include "../ScriptableElement/ScriptableElement.hpp"

class Entity;
class TextElement;
class UIElement;
class ScriptableElement;

//!
//! Contains every entity created by the game except the destroyed ones 
//!

extern vector<shared_ptr<Entity>> entities;
//!
//! Contains every texts created by the game except the destroyed ones 
//!

extern vector<shared_ptr<TextElement>> textElements;

//!
//! Contains every UIElements created by the game except the destroyed ones 
//!

extern vector<shared_ptr<UIElement>> uiElements;

//!
//! Contains every custom ScriptableElement created by the user except the destroyed ones 
//!

extern vector<shared_ptr<ScriptableElement>> scripts;

extern queue<std::string> freeIDs;

extern int lastID;

#endif /* !GAMEDATA_HPP_ */
