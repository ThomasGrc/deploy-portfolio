/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** vector3
*/

#ifndef VECTOR3_HPP_
#define VECTOR3_HPP_

template <typename T>
class vector3 {
    public:

        //!
        //! Constructor of class vector3
        //!
        vector3();

        //!
        //! Overload of vector3 
        //!
        vector3(T x, T y, T z);

        //!
        //! Destructor of class vector3
        //!
        ~vector3();

        static vector3<T> up();
        static vector3<T> down();
        static vector3<T> right();
        static vector3<T> left();
        static vector3<T> forward();
        static vector3<T> back();
        double getLength();
        vector3<double> normalize();

        vector3& operator=(const vector3& other);
        bool operator==(const vector3& other) const;

        T x;
        T y;
        T z;
};

template <typename T>
vector3<T>::vector3() 
{
    x = 0;
    y = 0;
}

template <typename T>
vector3<T>::~vector3() {}

template <typename T>
vector3<T>::vector3(T x, T y, T z) 
{
    this->x = x;
    this->y = y;
    this->z = z;
}

template <typename T>
vector3<T>& vector3<T>::operator=(const vector3<T>& other)
{
    x = other.x;
    y = other.y;
    z = other.z;
    return (*this);
}

template <typename T>
bool vector3<T>::operator==(const vector3<T>& other) const
{
    return (x == other.x && y == other.y && z == other.z);
}

template <typename T>
vector3<T> vector3<T>::up()
{
    return (vector3<T>(0, 1, 0));
}

template <typename T>
vector3<T> vector3<T>::down()
{
    return (vector3<T>(0, -1, 0));
}

template <typename T>
vector3<T> vector3<T>::right()
{
    return (vector3<T>(1, 0, 0));
}

template <typename T>
vector3<T> vector3<T>::left()
{
    return (vector3<T>(-1, 0, 0));
}

template <typename T>
vector3<T> vector3<T>::forward()
{
    return (vector3<T>(0, 0, 1));
}

template <typename T>
vector3<T> vector3<T>::back()
{
    return (vector3<T>(0, 0, -1));
}

template <typename T>
double vector3<T>::getLength()
{
    return sqrt((x * x) + (y * y) + (z * z));
}

template <typename T>
vector3<double> vector3<T>::normalize()
{
    double len = getLength();
    return vector3<double>(x / len, y / len, z / len);
}

#endif /* !VECTOR3_HPP_ */
