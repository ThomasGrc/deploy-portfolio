/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** vector
*/

#ifndef VECTOR2_HPP_
#define VECTOR2_HPP_

#include <math.h>

template <typename T>
class vector2 {
    public:
        //!
        //! Constructor class vector2
        //!
        vector2();

        //!
        //! Overload of constructor
        //!
        vector2(T x, T y);

        //!
        //! Destructor of class vector2
        //!
        ~vector2();
         
        static vector2<T> up();
        static vector2<T> down();
        static vector2<T> right();
        static vector2<T> left();
        double getLength();
        vector2<double> normalize();

        vector2& operator=(const vector2& other);
        bool operator==(const vector2& other) const;
    
        T x;
        T y;
};

template <typename T>
vector2<T>::vector2() 
{
    x = 0;
    y = 0;
}

template <typename T>
vector2<T>::~vector2() {}

template <typename T>
vector2<T>::vector2(T x, T y) 
{
    this->x = x;
    this->y = y;
}

template <typename T>
vector2<T>& vector2<T>::operator=(const vector2<T>& other)
{
    x = other.x;
    y = other.y;
    return (*this);
}

template <typename T>
bool vector2<T>::operator==(const vector2<T>& other) const
{
    return (x == other.x && y == other.y);
}

template <typename T>
vector2<T> vector2<T>::up()
{
    return (vector2<T>(0, 1));
}

template <typename T>
vector2<T> vector2<T>::down()
{
    return (vector2<T>(0, -1));
}

template <typename T>
vector2<T> vector2<T>::right()
{
    return (vector2<T>(1, 0));
}

template <typename T>
vector2<T> vector2<T>::left()
{
    return (vector2<T>(-1, 0));
}

template <typename T>
double vector2<T>::getLength()
{
    return sqrt((x * x) + (y * y));
}

template <typename T>
vector2<double> vector2<T>::normalize()
{
    double len = getLength();
    return vector2<double>(x / len, y / len);
}

#endif /* !VECTOR2_HPP_ */
