/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Time
*/

#ifndef TIME_HPP_
#define TIME_HPP_

#include <ctime>

class Time {
    public:
        Time();
        ~Time();

        // =================================================================
                            /* ----- METHODS ----- */
        // =================================================================
        //!
        //! Returns the current time 
        //!
        std::clock_t getTime() const;
        //!
        //! Returns elapsed time since the beginning of the frame 
        //!
        double getDeltaTime() const;
        //!
        //! Returns time since the last update call. DO NOT USE 
        //!
        double getUpdateDeltaTime() const;
        //!
        //! Returns elapsed time since the last frame. Use this for physics related updates, ... 
        //!
        double getTimeSinceLastFrame() const;

        // =================================================================
                            /* ---- VARIABLES ---- */
        // =================================================================
        //!
        //! Time of the beginning of the frame. Divide by (double)CLOCKS_PER_SEC to have it in seconds
        //!
        std::clock_t frameBgnTime;
        //!
        //! Time of the beginning of the updates. Divide by (double)CLOCKS_PER_SEC to have it in seconds
        //!
        std::clock_t updateBgnTime;
        //!
        //! total duration of the last frame
        //!
        double totalFrameTime=0;
    private:
};

extern Time timeHandler;

#endif /* !TIME_HPP_ */
