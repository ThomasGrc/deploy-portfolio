/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** DataBuffer
*/

#ifndef DATABUFFER_HPP_
#define DATABUFFER_HPP_

#include <vector>
#include <string>
#include <mutex>
#include <condition_variable>
#include <sstream>
#include "../DataTypes/GameData.hpp"


class DataBuffer {
    public:
        DataBuffer();
        ~DataBuffer();

        std::vector<std::string> getReceivedData(void) const;
        void addReceivedData(const std::string&);
        std::string popReceivedData(void);

        std::vector<std::string> getDataToSend(void) const;
        void addDataToSend(const std::string&);
        void addDataToSend(const Entity&);
        void addDataToSend(const TextElement&);
        void addDataToSend(const UIElement&);
        std::string popDataToSend(void);
    protected:
    private:
        std::vector<std::string> receivedData;
        std::vector<std::string> dataToSend;
};

#endif /* !DATABUFFER_HPP_ */
