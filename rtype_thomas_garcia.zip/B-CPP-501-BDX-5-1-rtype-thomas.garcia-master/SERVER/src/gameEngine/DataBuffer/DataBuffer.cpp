/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** DataBuffer
*/

#include "DataBuffer.hpp"

DataBuffer::DataBuffer()
{
}

DataBuffer::~DataBuffer()
{
}

std::vector<std::string> DataBuffer::getReceivedData(void) const
{
    return (receivedData);
}

void DataBuffer::addReceivedData(const std::string &arg)
{
    receivedData.push_back(arg);
}

std::string DataBuffer::popReceivedData(void)
{
    std::string data = receivedData.at(0);
    receivedData.erase(receivedData.begin());
    return data;
}

std::vector<std::string> DataBuffer::getDataToSend(void) const
{
    return (dataToSend);
}

void DataBuffer::addDataToSend(const std::string &arg)
{
    dataToSend.push_back(arg);
}

void DataBuffer::addDataToSend(const Entity &arg)
{
    std::string data;
    std::ostringstream oss; // using ostringstream = very ressource demanding -> find another way to convert fload/double to string

    data.append( "entity-" +
                 arg.getID() + "-" + 
                 arg.getName() + "-");
    oss << arg.getPosition().x;
    data.append( std::string(oss.str()) + ",");
    oss.str("");
    oss.clear();
    oss << arg.getPosition().y;
    data.append( std::string(oss.str()) );

    if (arg.hasCollider()) {
        data.append("-" + std::to_string(arg.getCollider()->getRect().width) + "," +
                          std::to_string(arg.getCollider()->getRect().height));
    }
    data.append("\n");
    dataToSend.push_back(data);
}

void DataBuffer::addDataToSend(const TextElement &arg)
{
    std::string data;
    std::ostringstream oss;

    data.append( "text-" +
                 arg.getID() + "-" + 
                 arg.getName() + "-");
    oss << arg.getPosition().x;
    data.append( std::string(oss.str()) + ",");
    oss.clear();
    oss << arg.getPosition().y;
    data.append( std::string(oss.str()) );

    if (arg.hasCollider()) {
        data.append("-" + std::to_string(arg.getCollider()->getRect().width) + "," +
                          std::to_string(arg.getCollider()->getRect().height));
    }
    data.append("-" + arg.getText());
    data.append("\n");
    dataToSend.push_back(data);
}

void DataBuffer::addDataToSend(const UIElement &arg)
{
    std::string data;
    std::ostringstream oss;

    data.append( "ui-" +
                 arg.getID() + "-" + 
                 arg.getName() + "-");
    oss << arg.getPosition().x;
    data.append( std::string(oss.str()) + ",");
    oss.clear();
    oss << arg.getPosition().y;
    data.append( std::string(oss.str()) );

    if (arg.hasCollider()) {
        data.append("-" + std::to_string(arg.getCollider()->getRect().width) + "," +
                          std::to_string(arg.getCollider()->getRect().height));
    }
    data.append("-" + arg.getSprite());
    data.append("\n");
    dataToSend.push_back(data);
}

std::string DataBuffer::popDataToSend(void)
{
    std::string data = dataToSend.at(0);
    dataToSend.erase(dataToSend.begin());

    return data;
}