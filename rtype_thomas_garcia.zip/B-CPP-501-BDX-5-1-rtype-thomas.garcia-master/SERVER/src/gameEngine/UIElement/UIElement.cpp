/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** UIElement
*/

#include "UIElement.hpp"

UIElement::UIElement()
{
    if (!freeIDs.empty()) {
        this->id = freeIDs.back();
        freeIDs.pop(); // TODO -> implement smth to block the usage of the queue by other classes when accessing data here
    } else {
        this->id = std::to_string(lastID + 1);
        lastID++;
    }

    collider = nullptr;
}

UIElement::~UIElement()
{
    freeIDs.push(this->id);
}

// called upon game start
void UIElement::start()
{
    collider = nullptr;
}

// called inside game loop (on non a regular time line)
void UIElement::update()
{
    
}

// called inside game loop (on a regular time line)
void UIElement::fixedUpdate()
{

}

// called when clicked on and the position of the click is passed as parameter
void UIElement::onClick(vector2<double> click)
{

}

// returns true of the text has a collider
bool UIElement::hasCollider(void) const
{
    if (collider != nullptr)
        return true;
    return false;
}

string UIElement::getID(void) const
{
    return (id);
}

shared_ptr<UICollider> UIElement::getCollider(void) const
{
    return (collider);
}

vector2<double> UIElement::getPosition(void) const
{
    return (position);
}

string UIElement::getName(void) const
{
    return (name);
}

string UIElement::getSprite(void) const
{
    return (sprite);
}

void UIElement::setCollider(const shared_ptr<UICollider> &arg)
{
    collider = arg;
}

void UIElement::setPosition(const vector2<double> &arg)
{
    position = arg;
    if (hasCollider()) {
        collider->move(arg);
    }
}

void UIElement::setName(const string &arg)
{
    name = arg;
}

void UIElement::setSprite(const string &arg)
{
    sprite = arg;
}