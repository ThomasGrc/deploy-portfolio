/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** UIElement
*/

#ifndef UIELEMENT_HPP_
#define UIELEMENT_HPP_

#include <string>
#include <memory>
#include <uuid/uuid.h>
#include "../Time/Time.hpp"
#include "../Colliders/UICollider.hpp"
#include "../DataTypes/rectangle.hpp"
#include "../DataTypes/vector2.hpp"
#include "../DataTypes/GameData.hpp"

using namespace std;

class UIElement {
    public:
        //!
        //! Constructor of class UIElement
        //!
        UIElement();

        //!
        //! Destructor of class UIELement
        //!
        ~UIElement();

        // =================================================================
                            /* ----- METHODS ----- */
        // =================================================================
        //!
        //! Called upon game start
        //!
        virtual void start();
        //!
        //! called inside game loop (on non a regular time line)
        //!
        virtual void update();
        //!
        //! called inside game loop (on a regular time line)
        //!
        virtual void fixedUpdate();
        //!
        //! Called when the UIElement is clicked on
        //! click   The position at which the click occured
        //!
        virtual void onClick(vector2<double> click);

        // =================================================================
                            /* ----- GETTERS ----- */
        // =================================================================
        //!
        //! returns true of the entity has a collider
        //!
        bool hasCollider(void) const;
        string getID(void) const;
        shared_ptr<UICollider> getCollider(void) const;
        vector2<double> getPosition(void) const;
        string getName(void) const;
        string getSprite(void) const;

        // =================================================================
                            /* ----- SETTERS ----- */
        // =================================================================
        void setCollider(const shared_ptr<UICollider>&);
        void setPosition(const vector2<double>&);
        void setName(const string&);
        void setSprite(const string&);

    protected:
        // =================================================================
                            /* ---- VARIABLES ---- */
        // =================================================================
        //!
        //! unique ID associated with that specific UI element
        //!
        string id = "";
        shared_ptr<UICollider> collider;
        vector2<double> position = {0.0, 0.0};
        //!
        //! name of the sprite associated with that UI element
        //!
        string sprite = "";
        string name = "";
        
};

#endif /* !UIELEMENT_HPP_ */
