/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Collision
*/

#include "Collision.hpp"

struct Rect
{
  Rect()  {}

  Rect(double a_minX, double a_minY, double a_maxX, double a_maxY)
  {
    min[0] = a_minX;
    min[1] = a_minY;

    max[0] = a_maxX;
    max[1] = a_maxY;
  }


  double min[2];
  double max[2];
};

std::vector<size_t> didCollideWithID;

Collision::Collision()
{
}

Collision::~Collision()
{
}

void Collision::AddAll(vector<shared_ptr<Entity>> objects)
{
    for(size_t i = 0; i < objects.size(); i++) {
        Rect rect(objects[i]->getCollider()->getRect().x, 
                  objects[i]->getCollider()->getRect().y,
                  objects[i]->getCollider()->getRect().x + objects[i]->getCollider()->getRect().width,
                  objects[i]->getCollider()->getRect().y + objects[i]->getCollider()->getRect().height);
        tree.Insert(rect.min, rect.max, i); // Note, all values including zero are fine in this version
    }
}

void Collision::DeleteAll()
{
    tree.RemoveAll();
}

bool searchCallback(int id) 
{
    didCollideWithID.push_back( id );
    return true; // keep going through RTree search
}

void Collision::SearchAll(vector<shared_ptr<Entity>> objects)
{
    didCollideWithID.clear();
    didCollideWithID.shrink_to_fit();
    for(size_t i = 0; i < objects.size(); i++) {
        Rect search_rect(6, 4, 10, 6);
        Rect rect(objects[i]->getCollider()->getRect().x, 
                  objects[i]->getCollider()->getRect().y,
                  objects[i]->getCollider()->getRect().x + objects[i]->getCollider()->getRect().width,
                  objects[i]->getCollider()->getRect().y + objects[i]->getCollider()->getRect().height);
        int hits = tree.Search(rect.min, rect.max, searchCallback);
        for (size_t j = 0; j < didCollideWithID.size(); j++) {
            if (didCollideWithID[j] != i) {
                objects[i]->onCollision(*objects[didCollideWithID[j]].get());
            }
        }
        didCollideWithID.clear();
        didCollideWithID.shrink_to_fit();
    }
}