/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Collision
*/

#ifndef COLLISION_HPP_
#define COLLISION_HPP_

#include <vector>
#include "RTree/RTree.h"
#include "../Entity/Entity.hpp"
#include "../DataTypes/rectangle.hpp"

class Collision {
    public:
        //!
        //! Constructor of class collision
        //!
        Collision();

        //!
        //! Destructor of class collision
        //!
        ~Collision();

        //!
        //! Add all objects
        //!
        void AddAll(vector<shared_ptr<Entity>> objects);

        //!
        //! Delete all objects
        //!
        void DeleteAll();

        //!
        //! Search all objects
        //!
        void SearchAll(vector<shared_ptr<Entity>> objects);

    private:
        RTree<int, double, 2, double> tree;
};

#endif /* !COLLISION_HPP_ */
