/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Entity
*/

#include "Entity.hpp"

Entity::Entity()
{
    if (!freeIDs.empty()) {
        this->id = freeIDs.back();
        freeIDs.pop(); // TODO -> implement smth to block the usage of the queue by other classes when accessing data here
    } else {
        this->id = std::to_string(lastID + 1);
        lastID++;
    }

    collider = nullptr;
    actionHandler = nullptr;
}

Entity::Entity(double posX, double posY)
{
    this->position.x = posX;
    this->position.y = posY;

    if (!freeIDs.empty()) {
        this->id = freeIDs.back();
        freeIDs.pop(); // TODO -> implement smth to block the usage of the queue by other classes when accessing data here
    } else {
        this->id = std::to_string(lastID + 1);
        lastID++;
    }
    collider = nullptr;
    actionHandler = nullptr;
}

Entity::Entity(double posX, double posY, double length, double height)
{
    this->position.x = posX;
    this->position.y = posY;

    if (!freeIDs.empty()) {
        this->id = freeIDs.back();
        freeIDs.pop(); // TODO -> implement smth to block the usage of the queue by other classes when accessing data here
    } else {
        this->id = std::to_string(lastID + 1);
        lastID++;
    }
    collider = nullptr;
    actionHandler = nullptr;

    rectangle<double> hitbox( posX, posY, length, height);
    this->setCollider(std::make_shared<SpriteCollider>(hitbox));
}

Entity::~Entity()
{
    freeIDs.push(this->id);
}

// called upon game start
void Entity::start()
{

}

// called inside game loop (on non a regular time line)
void Entity::update()
{
    
}

// called inside game loop (on a regular time line)
void Entity::fixedUpdate()
{

}

// called upon collision with another IEntity that has a collider. Reference to said entity is passed as parameter
void Entity::onCollision(Entity &other)
{

}

// returns true of the text has a collider
bool Entity::hasCollider(void) const
{
    if (collider != nullptr)
        return true;
    return false;
}

bool Entity::hasActionHandler(void) const
{
    if (actionHandler != nullptr)
        return true;
    return false;
}

string Entity::getID(void) const
{
    return (id);
}

shared_ptr<SpriteCollider> Entity::getCollider(void) const
{
    return (collider);
}

std::shared_ptr<ActionHandler> Entity::getActionHandler(void) const
{
    return (actionHandler);
}

vector2<double> Entity::getPosition(void) const
{
    return (position);
}

string Entity::getName(void) const
{
    return (name);
}

void Entity::setCollider(const shared_ptr<SpriteCollider> &arg)
{
    collider = arg;
}

void Entity::addActionHandler(void)
{
    actionHandler = std::make_shared<ActionHandler>();
}

void Entity::setPosition(const vector2<double> &arg)
{
    position = arg;
    if (hasCollider()) {
        collider->move(arg);
    }
}

void Entity::setName(const string &arg)
{
    name = arg;
}
