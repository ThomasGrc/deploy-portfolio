/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** Entity
*/

#ifndef ENTITY_HPP_
#define ENTITY_HPP_


#include <string>
#include <memory>
#include "Entity.hpp"
#include "../Time/Time.hpp"
#include "../Colliders/SpriteCollider.hpp"
#include "../DataTypes/rectangle.hpp"
#include "../DataTypes/vector2.hpp"
#include "../Input/ActionHandler.hpp"
#include "../DataTypes/GameData.hpp"

using namespace std;

//!
//! Base class for any entity to be created
//!

class Entity {
    public:
        Entity();
        Entity(double posX, double posY);
        Entity(double posX, double posY, double length, double height);
        ~Entity();

        // =================================================================
                            /* ----- METHODS ----- */
        // =================================================================
        //!
        //! Called upon game start
        //!

        virtual void start();

        //!
        //! Called inside game loop (on non a regular time line)
        //!

        virtual void update();

        //!
        //! Called inside game loop (on a regular time line). This function is preferable over update() for every physics related updates
        //!

        virtual void fixedUpdate();

        //!
        //! called upon collision with another IEntity that has a collider. Reference to said entity is passed as parameter.
        //! other   The other entity with which this one collided
        //!

        virtual void onCollision(Entity &other);

        // =================================================================
                            /* ----- GETTERS ----- */
        // =================================================================

        //!
        //! returns true of the entity has a collider
        //!

        bool hasCollider(void) const;
        bool hasActionHandler(void) const;
        string getID(void) const;
        shared_ptr<SpriteCollider> getCollider(void) const;
        std::shared_ptr<ActionHandler> getActionHandler(void) const;
        vector2<double> getPosition(void) const;
        string getName(void) const;

        // =================================================================
                            /* ----- SETTERS ----- */
        // =================================================================
        void setCollider(const shared_ptr<SpriteCollider>&);
        void addActionHandler(void);
        void setPosition(const vector2<double>&);
        void setName(const string&);

    protected:
        // =================================================================
                            /* ---- VARIABLES ---- */
        // =================================================================
        //!
        //! unique ID associated with that specific entity
        //!

        string id = "";
        shared_ptr<SpriteCollider> collider;
        std::shared_ptr<ActionHandler> actionHandler;
        vector2<double> position = {0.0, 0.0};
        //!
        //! name of the sprite associated with that entity
        //!
        string name = "";

};

#endif /* !ENTITY_HPP_ */
