#ifndef TCP_CONNECTION
#define TCP_CONNECTION

#include <boost/asio.hpp>
#include <mutex>
#include <iostream>
#include <array>
#include <memory>
#include "../DataBuffer/DataBuffer.hpp"

using boost::asio::ip::tcp;

class tcp_connection :
    public std::enable_shared_from_this<tcp_connection>
{
public:
  typedef std::shared_ptr<tcp_connection> pointer;
  static pointer create(std::shared_ptr<boost::asio::io_context> &io_context, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<std::mutex> _mutex)
  {
    return pointer(std::make_shared<tcp_connection>(io_context , tcpDataBuffer, _mutex));
  }
  tcp_connection(std::shared_ptr<boost::asio::io_context> &io_context, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<std::mutex> mutex);
  std::shared_ptr<tcp::socket>& socket();
  void start();
  void write(std::string data);
  std::shared_ptr<std::mutex> getMutex(void) const;


private:
  void read();
  void close();

  enum { max_length = 1024 };
  std::shared_ptr<boost::asio::io_context> io_context;
  std::shared_ptr<tcp::socket> socket_;
  std::shared_ptr<DataBuffer> tcpDataBuffer_;
  std::array<char, 128> m_network_buffer;
  boost::asio::streambuf streambuf;
  std::shared_ptr<std::mutex> mutex;
};

#endif