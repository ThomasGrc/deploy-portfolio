#ifndef TCPSERVER
#define TCPSERVER

#include <mutex>
#include <memory>
#include "../DataBuffer/DataBuffer.hpp"
#include "TcpConnection.hpp"

using boost::asio::ip::tcp;

class tcp_server
{
public:
    tcp_server(std::shared_ptr<boost::asio::io_context> &io_context, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<std::mutex> mutex);
    ~tcp_server();

    void sendToAll();
private:
    void start_accept();

    void handle_accept(const tcp_connection::pointer& new_connection, const std::error_code& error);
    std::shared_ptr<boost::asio::io_context> io_context;
    tcp::acceptor acceptor_;
    std::vector<std::shared_ptr<tcp_connection>> sessions_;
    std::shared_ptr<DataBuffer> tcpDataBuffer;
    std::shared_ptr<std::mutex> mutex;
};

#endif // !TCPSERVER