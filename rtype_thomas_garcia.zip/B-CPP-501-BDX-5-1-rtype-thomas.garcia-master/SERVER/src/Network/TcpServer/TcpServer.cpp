#include "TcpServer.hpp"

tcp_server::tcp_server(std::shared_ptr<boost::asio::io_context> &io_context, std::shared_ptr<DataBuffer> tcpDataBuffer_, std::shared_ptr<std::mutex> mutex)
    : acceptor_(*(io_context.get()), tcp::endpoint(tcp::v4(), 13)), tcpDataBuffer(tcpDataBuffer_), io_context(io_context)
{
    // this->io_context = io_context;
    this->mutex = mutex;
    start_accept();
}

tcp_server::~tcp_server()
{
}

#include <iostream>

void tcp_server::sendToAll()
{
    mutex->lock();
    while (!tcpDataBuffer->getDataToSend().empty()) {
        std::string data = tcpDataBuffer->popDataToSend();

        for(auto session : sessions_) {
            session->write(data);
        }
    }
    mutex->unlock();
}

void tcp_server::start_accept()
{
    // sessions_.push_back(tcp_connection::create(static_cast<boost::asio::io_context&>(acceptor_.get_executor().context()), tcpDataBuffer, mutex));
    sessions_.push_back(tcp_connection::create(io_context, tcpDataBuffer, mutex));
    auto handler = [new_connection = sessions_[sessions_.size() - 1] , this](const boost::system::error_code &error) {
        this->handle_accept(new_connection, error);
    };
    acceptor_.async_accept(*(sessions_[sessions_.size() - 1]->socket().get()), handler);
}

void tcp_server::handle_accept(const tcp_connection::pointer& new_connection, const std::error_code& error)
{
    if (!error)
    {
        mutex->lock();
        std::cout << "Reçu un client!" << std::endl;
        tcpDataBuffer->addReceivedData("connected");
        mutex->unlock();
        new_connection->start();
    } else {
        std::cerr << "error in handle_accept: " << error << std::endl;
    }
    start_accept();
}