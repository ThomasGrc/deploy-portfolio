#include "TcpConnection.hpp"

tcp_connection::tcp_connection(std::shared_ptr<boost::asio::io_context> &io_context, std::shared_ptr<DataBuffer> tcpDataBuffer, std::shared_ptr<std::mutex> mutex)
: tcpDataBuffer_(tcpDataBuffer), io_context(io_context)
{
    // this->io_context = io_context;
    // socket_ = std::make_shared<tcp::socket>(*(io_context->getContext().get()));
    socket_ = std::make_shared<tcp::socket>(*(io_context.get()));
    this->mutex = mutex;
}

void tcp_connection::start()
{
    read();
}

void tcp_connection::read()
{
    auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
        {
            if (!error) {
                self->streambuf.commit(bytes_transferred);
                std::istream ss(&self->streambuf);
                std::string str;
                ss >> str;
                self->getMutex()->lock();
                std::cout << "Received: " << str << std::endl;
                self->tcpDataBuffer_->addReceivedData(str);
                self->getMutex()->unlock();
                self->read();
            }
            else {
                std::cout << "error on recv: " << error.message() << std::endl;
            }
        };
    if (socket_->is_open()) {
        boost::asio::async_read_until(*(socket_.get()), streambuf, '\n', handler);
    } else {
        std::cerr << "socket closed" << std::endl;
    }
}

void tcp_connection::write(std::string data)
{
    // not calling mutex->lock here since it is already called in TcpServer::sendToAll which calls this method
    auto writeHandler = [self = shared_from_this()] (const boost::system::error_code &error, std::size_t size) {
        if (!error) {
            self->read();
            std::cout << "Server send" << std::endl;
        } else {
            std::cerr << "error on send: " << error.message() << std::endl;
            self->socket_->close();
        }
    };
    if (socket_->is_open()) {
        boost::asio::async_write(*(socket_.get()), boost::asio::buffer(data), writeHandler);
    } else {
        std::cerr << "socket closed" << std::endl;
    }
}

void tcp_connection::close()
{
    socket_->close();
}

std::shared_ptr<tcp::socket>& tcp_connection::socket()
{
    return socket_;
}

std::shared_ptr<std::mutex> tcp_connection::getMutex(void) const
{
    return mutex;
}