/*
** EPITECH PROJECT, 2020
** B-CPP-501-BDX-5-1-rtype-thomas.garcia
** File description:
** DataBuffer
*/

#include "DataBuffer.hpp"

DataBuffer::DataBuffer()
{
}

DataBuffer::~DataBuffer()
{
}

std::vector<std::string> DataBuffer::getReceivedData(void) const
{
    return (receivedData);
}

#include <iostream>
void DataBuffer::addReceivedData(const std::string &arg)
{
    std::cout << arg << std::endl;
    receivedData.push_back(arg);
}

std::string DataBuffer::popReceivedData(void)
{
    std::string data = receivedData.at(0);
    receivedData.erase(receivedData.begin());
    return data;
}

std::vector<std::string> DataBuffer::getDataToSend(void) const
{
    return (dataToSend);
}

void DataBuffer::addDataToSend(const std::string &arg)
{
    dataToSend.push_back(arg);
}

std::string DataBuffer::popDataToSend(void)
{
    std::string data = dataToSend.at(0);
    dataToSend.erase(dataToSend.begin());

    return data;
}