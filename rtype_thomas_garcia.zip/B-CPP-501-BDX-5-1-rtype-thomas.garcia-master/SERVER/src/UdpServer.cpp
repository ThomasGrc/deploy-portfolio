#include <iostream>
#include <memory>
#include <boost/array.hpp>
// #include <boost/bind.hpp>
#include <boost/asio.hpp>

using boost::asio::ip::udp;

class UdpServer : public std::enable_shared_from_this<UdpServer>
{
public:
    UdpServer(boost::asio::io_service& io_service)
        : socket_(io_service, udp::endpoint(udp::v4(), 13))
    {
    }

    void recv() {

        auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
            {
                if (!error) {
                    std::cout << "message received: " << self->message << std::endl;
                    self->recv();
                    self->send(std::string(self->message));
                } else {
                    std::cout << "Error on receive: " << error.message() << "\n";

                    // self->stop();
                }
            };

        socket_.async_receive_from(boost::asio::buffer(message, max_length), remote_endpoint_, handler);
    }

    void send(std::string /* message */) {
        boost::shared_ptr<std::string> message(new std::string("message"));

        auto handler = [self = shared_from_this()] (boost::system::error_code error, std::size_t bytes_transferred)
            {
                if (!error) {
                    std::cout << "message sent" << std::endl;
                } else {
                    std::cout << "Error on receive: " << error.message() << "\n";

                    // self->stop();
                }
            };

        socket_.async_send_to(boost::asio::buffer(*message), remote_endpoint_, handler);
    }

private:

    udp::socket socket_;
    udp::endpoint remote_endpoint_;
    enum { max_length = 1024 };

    char message[max_length];
    // boost::array<char, 1024> recv_buffer_;
};

int main()
{
    try
    {
        boost::asio::io_service io_service;
        std::shared_ptr<UdpServer> server = std::make_shared<UdpServer>(io_service);
        server->recv();
        io_service.run();
    }
    catch (std::exception& e)
    {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}