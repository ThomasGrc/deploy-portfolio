#ifndef EXCEPTION_SERVER_HPP_
#define EXCEPTION_SERVER_HPP_

#include <iostream>
#include <exception>

class ExceptionClient : public std::exception {
    public:
        ExceptionClient(const char *msg, const char *func);
        ~ExceptionClient();

		const char *get_func(void) const;
        const char *what() const throw ();

    protected:
    private:
        const char *_msg;
        const char *_func;
};

#endif /* !EXCEPTION_SERVER_HPP_ */