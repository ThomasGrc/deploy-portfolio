#include "ExceptionClient.hpp"

ExceptionClient::ExceptionClient(const char *msg, const char *func)
{
    _msg = msg;
    _func = func; 
}

ExceptionClient::~ExceptionClient()
{
}

const char *ExceptionClient::get_func(void) const
{
    return (_func);
}

const char *ExceptionClient::what() const throw () 
{
    return _msg;
}