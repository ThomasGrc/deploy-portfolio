var searchData=
[
  ['updatebgntime_270',['updateBgnTime',['../class_time.html#ad20b3d56bac2e8aed980d2907785a3ed',1,'Time']]]
];
