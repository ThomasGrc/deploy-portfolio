var searchData=
[
  ['node_146',['Node',['../struct_r_tree_1_1_node.html',1,'RTree']]]
];
