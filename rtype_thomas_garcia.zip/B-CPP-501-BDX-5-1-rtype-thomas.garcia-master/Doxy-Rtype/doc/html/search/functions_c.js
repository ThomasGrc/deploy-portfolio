var searchData=
[
  ['pause_216',['PAUSE',['../class_p_a_u_s_e.html#ab1ccd626172d34a255efc2a685399666',1,'PAUSE::PAUSE(std::shared_ptr&lt; sf::RenderWindow &gt; window)'],['../class_p_a_u_s_e.html#a912016890b010cd4a705753e4bebd34a',1,'PAUSE::pause(std::shared_ptr&lt; TcpClient &gt; client)']]]
];
