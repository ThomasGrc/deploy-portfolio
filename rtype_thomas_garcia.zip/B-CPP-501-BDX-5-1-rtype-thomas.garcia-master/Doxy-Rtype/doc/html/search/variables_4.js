var searchData=
[
  ['sprite_267',['sprite',['../class_u_i_element.html#a16a3dddc36171836301cc844abc89f6a',1,'UIElement']]]
];
