var searchData=
[
  ['text_268',['text',['../class_text_element.html#a62ddf55b41da92ca29fe911fa138d68d',1,'TextElement']]],
  ['totalframetime_269',['totalFrameTime',['../class_time.html#a3f94a5faeecef3fe89c139573bba8afe',1,'Time']]]
];
