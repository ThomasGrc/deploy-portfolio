var searchData=
[
  ['branch_130',['Branch',['../struct_r_tree_1_1_branch.html',1,'RTree']]]
];
