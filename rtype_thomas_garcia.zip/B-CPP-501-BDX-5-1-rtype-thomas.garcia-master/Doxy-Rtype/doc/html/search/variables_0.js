var searchData=
[
  ['framebgntime_252',['frameBgnTime',['../class_time.html#a24d715697a2aaf724ed319d6910a9f37',1,'Time']]]
];
