var searchData=
[
  ['maxnodes_271',['MAXNODES',['../class_r_tree.html#afaccb2e611f17ff46b623771ad7043d7ac05afe446df73fa67991e5199453a37f',1,'RTree']]],
  ['minnodes_272',['MINNODES',['../class_r_tree.html#afaccb2e611f17ff46b623771ad7043d7a3be3d8c82fd5bfbd5e5a496e9877d71a',1,'RTree']]]
];
