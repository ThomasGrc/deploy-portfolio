How to use Doxygen : 
    First : ./doxysetup.sh

Then when you want to generate a new version of your documentation just type : 
    ./doxygenerate.sh



COMMENT FORMAT: 
    Style C++ avec trois / :
        ///
        /// ... Documentation ...
        ///

    Style C++ avec un ! :
        //!
        //! ... Documentation ...
        //!