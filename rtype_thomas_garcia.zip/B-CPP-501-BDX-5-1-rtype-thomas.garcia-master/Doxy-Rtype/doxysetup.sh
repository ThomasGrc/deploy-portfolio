#!/bin/sh
sudo dnf install doxygen
chmod 777 doxygenerate.sh
